
import React, { useState } from "react";
import { Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";

interface PaymentStepsProps {
  amount: number;
  tillNumber: string;
  onMessageChange?: (message: string) => void;
  mpesaMessage?: string;
  showMessageInput?: boolean;
}

const PaymentSteps: React.FC<PaymentStepsProps> = ({ 
  amount, 
  tillNumber, 
  onMessageChange,
  mpesaMessage = "",
  showMessageInput = false
}) => {
  const { toast } = useToast();

  const handleCopyTill = () => {
    navigator.clipboard.writeText(tillNumber);
    toast({
      title: "Till number copied",
      description: "You can now paste it in your M-PESA app",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 mr-3">
          1
        </div>
        <div>
          <p className="text-gray-700">Go to M-PESA</p>
        </div>
      </div>

      <div className="flex items-start">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 mr-3">
          2
        </div>
        <div>
          <p className="text-gray-700">Select &quot;Lipa na M-PESA&quot; &gt; &quot;Buy Goods&quot;</p>
        </div>
      </div>

      <div className="flex items-start">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 mr-3">
          3
        </div>
        <div className="flex-grow">
          <p className="text-gray-700 mb-2">Enter Till</p>
          <div className="flex items-center">
            <div className="bg-gray-100 py-2 px-3 rounded-md text-gray-800 font-medium flex-grow">
              {tillNumber}
            </div>
            <Button variant="ghost" size="icon" onClick={handleCopyTill} className="ml-2">
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="flex items-start">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 mr-3">
          4
        </div>
        <div>
          <p className="text-gray-700">Enter Amount: KES {amount.toFixed(2)}</p>
        </div>
      </div>

      <div className="flex items-start">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 mr-3">
          5
        </div>
        <div>
          <p className="text-gray-700">Enter PIN &amp; Confirm</p>
        </div>
      </div>

      {showMessageInput && (
        <div className="pt-4 border-t border-gray-200">
          <label htmlFor="mpesa-message" className="block text-sm font-medium text-gray-700 mb-2">
            Full M-PESA Message
          </label>
          <Textarea
            id="mpesa-message"
            placeholder="Paste the full M-PESA confirmation message here..."
            value={mpesaMessage}
            onChange={e => onMessageChange && onMessageChange(e.target.value)}
            className="min-h-[80px] w-full"
          />
          <p className="text-xs text-gray-500 mt-1">
            Copy and paste the entire M-PESA confirmation message you received
          </p>
        </div>
      )}
    </div>
  );
};

export default PaymentSteps;
