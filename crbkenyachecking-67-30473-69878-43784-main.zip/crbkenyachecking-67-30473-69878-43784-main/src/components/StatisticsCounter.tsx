
import React, { useState, useEffect } from "react";
import { Users } from "lucide-react";

const HOURLY_INCREMENT = 20;
const HOURS_IN_WEEK = 24 * 7; // 168 hours in a week
const BASE_COUNT = 8500;

export const StatisticsCounter = () => {
  const [count, setCount] = useState(BASE_COUNT);

  useEffect(() => {
    // Function to calculate the current count based on time
    const calculateCount = () => {
      const now = new Date();
      // Get milliseconds since epoch
      const currentTimeMs = now.getTime();
      // Convert to hours (ms to hours)
      const currentTimeHours = Math.floor(currentTimeMs / (1000 * 60 * 60));
      // Get hours within a week cycle (0-167)
      const hoursInCurrentWeek = currentTimeHours % HOURS_IN_WEEK;
      // Calculate count: base count + (hours * increment)
      const calculatedCount = BASE_COUNT + (hoursInCurrentWeek * HOURLY_INCREMENT);
      
      return calculatedCount;
    };

    // Set initial count
    setCount(calculateCount());

    // Update the count every minute to ensure we catch hour changes
    const interval = setInterval(() => {
      setCount(calculateCount());
    }, 60000); // Check every minute

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex justify-center">
      <div className="bg-primary rounded-full py-3 px-6 shadow-lg animate-pulse-slow flex items-center">
        <div className="flex -space-x-3 mr-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-10 w-10 rounded-full bg-white/20 border-2 border-primary flex items-center justify-center">
              <Users className="h-5 w-5 text-white" />
            </div>
          ))}
        </div>
        <div className="text-white">
          <span className="font-bold text-xl text-accent mr-2">{count.toLocaleString()}+</span>
          <span className="font-medium">Kenyans checked their CRB status this week</span>
        </div>
      </div>
    </div>
  );
};

export default StatisticsCounter;
