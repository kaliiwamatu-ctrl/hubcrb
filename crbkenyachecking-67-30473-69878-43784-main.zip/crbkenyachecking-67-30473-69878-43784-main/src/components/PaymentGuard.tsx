
import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import CustomSubscriptionModal from "./CustomSubscriptionModal";
import { useToast } from "@/hooks/use-toast";

interface PaymentGuardProps {
  children: React.ReactNode;
}

const PaymentGuard: React.FC<PaymentGuardProps> = ({ children }) => {
  const { toast } = useToast();
  const [isSubscribed, setIsSubscribed] = useState<boolean | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  useEffect(() => {
    const checkPaymentStatus = () => {
      const hasSubscription = localStorage.getItem("isSubscribed") === "true";
      setIsSubscribed(hasSubscription);
      
      if (!hasSubscription) {
        toast({
          title: "Payment Required",
          description: "You need to complete payment to access the dashboard",
          variant: "destructive",
        });
        setShowPaymentModal(true);
      }
    };
    
    checkPaymentStatus();
  }, [toast]);

  if (isSubscribed === null) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }
  
  if (!isSubscribed) {
    return (
      <>
        <CustomSubscriptionModal
          open={showPaymentModal}
          onOpenChange={setShowPaymentModal}
          forceOpen={true} // New prop to force modal open
        />
        <Navigate to="/" replace />
      </>
    );
  }

  return <>{children}</>;
};

export default PaymentGuard;
