
import React from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle } from "lucide-react";
import { Payment } from "@/types/supabase";

interface PaymentWithUserDetails extends Payment {
  user_details?: {
    email: string;
  };
}

interface AdminPaymentDetailsProps {
  payment: PaymentWithUserDetails;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApprove: (paymentId: string) => void;
  onReject: (paymentId: string) => void;
}

const AdminPaymentDetails: React.FC<AdminPaymentDetailsProps> = ({
  payment,
  open,
  onOpenChange,
  onApprove,
  onReject
}) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Payment Details</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="font-medium">User:</div>
            <div className="col-span-2">{payment.user_details?.email || 'Unknown'}</div>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="font-medium">Amount:</div>
            <div className="col-span-2">{payment.currency || 'KES'} {payment.amount.toFixed(2)}</div>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="font-medium">Date:</div>
            <div className="col-span-2">
              {new Date(payment.created_at).toLocaleString()}
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="font-medium">Status:</div>
            <div className="col-span-2">
              <span className={`px-2 py-1 text-xs rounded-full ${
                payment.status === 'approved' 
                  ? 'bg-green-100 text-green-800' 
                  : payment.status === 'rejected'
                  ? 'bg-red-100 text-red-800'
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
              </span>
            </div>
          </div>
          
          <div>
            <div className="font-medium mb-2">Payment Details:</div>
            <div className="p-3 bg-gray-50 rounded-md border text-sm whitespace-pre-wrap break-words">
              {payment.description || payment.mpesa_message || 'No details available'}
            </div>
          </div>
        </div>
        
        {payment.status === 'pending' && (
          <DialogFooter>
            <Button 
              variant="outline" 
              className="border-red-500 text-red-500 hover:bg-red-50 hover:text-red-600"
              onClick={() => {
                onReject(payment.id);
                onOpenChange(false);
              }}
            >
              <XCircle className="h-4 w-4 mr-1" />
              Reject Payment
            </Button>
            
            <Button 
              className="bg-green-500 hover:bg-green-600"
              onClick={() => {
                onApprove(payment.id);
                onOpenChange(false);
              }}
            >
              <CheckCircle className="h-4 w-4 mr-1" />
              Approve Payment
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default AdminPaymentDetails;
