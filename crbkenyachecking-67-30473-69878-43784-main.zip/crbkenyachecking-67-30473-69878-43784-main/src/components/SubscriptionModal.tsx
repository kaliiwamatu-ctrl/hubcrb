
import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Check, Crown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";

interface SubscriptionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ open, onOpenChange }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [standardPrice, setStandardPrice] = useState(0);
  const [premiumPrice, setPremiumPrice] = useState(0);
  
  // Get user information from localStorage to display at top of modal
  const userName = localStorage.getItem("userName") || "User";
  const userId = localStorage.getItem("userId") || "Not available";

  // Set random prices when the modal opens
  useEffect(() => {
    if (open) {
      // Generate random prices within specified ranges
      const randomStandardPrice = Math.floor(Math.random() * (175 - 140 + 1)) + 140;
      const randomPremiumPrice = Math.floor(Math.random() * (250 - 180 + 1)) + 180;
      
      setStandardPrice(randomStandardPrice);
      setPremiumPrice(randomPremiumPrice);
    }
  }, [open]);

  const handleSubscribe = (plan: string) => {
    // In a real app, this would connect to a payment processor
    localStorage.setItem("subscriptionPlan", plan);
    localStorage.setItem("isSubscribed", "true");
    
    toast({
      title: "Subscription Successful!",
      description: `You've subscribed to the ${plan} plan.`,
      variant: "default",
    });
    
    onOpenChange(false);
    navigate("/dashboard");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="p-0 rounded-2xl overflow-hidden max-w-3xl w-[calc(100%-24px)]">
        {/* Header with user info */}
        <div className="p-6 text-center border-b">
          <h2 className="text-2xl font-bold">Hello {userName.toUpperCase()}</h2>
          <p className="text-muted-foreground">ID Number: {userId}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
          {/* Standard Report */}
          <div className="rounded-xl border overflow-hidden">
            <div className="p-6">
              <h3 className="text-xl font-bold">Standard Report</h3>
              <p className="text-muted-foreground mb-2">Basic credit information</p>
              
              <div className="text-3xl font-bold mb-4">
                KES {standardPrice}
                <span className="text-sm font-normal text-muted-foreground ml-1">One-time payment</span>
              </div>
              
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Credit Score Analysis</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Payment History Overview</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Credit Utilization Report</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Basic Recommendations</span>
                </li>
              </ul>
            </div>
            
            <div className="mt-auto">
              <Button 
                onClick={() => handleSubscribe("Standard")}
                className="w-full rounded-none h-12 bg-purple-500 hover:bg-purple-600 text-white font-medium"
                size="lg"
              >
                Select Standard →
              </Button>
            </div>
          </div>
          
          {/* Gold Premium */}
          <div className="rounded-xl border-2 border-yellow-100 bg-yellow-50/30 overflow-hidden relative">
            <div className="absolute top-0 right-0 bg-yellow-500 text-white px-3 py-1 text-xs rounded-bl-lg font-medium">
              RECOMMENDED
            </div>
            
            <div className="p-6">
              <div className="flex items-center space-x-2">
                <Crown className="h-5 w-5 text-yellow-500" />
                <h3 className="text-xl font-bold">Gold Premium</h3>
              </div>
              <p className="text-muted-foreground mb-2">Enhanced credit insights</p>
              
              <div className="text-3xl font-bold mb-4">
                KES {premiumPrice}
                <span className="text-sm font-normal text-muted-foreground ml-1">One-time payment</span>
              </div>
              
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>All Standard Features</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Loan Application Matches</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Credit Score Simulator</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Personalized Improvement Plan</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Monthly Score Updates</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span>Direct Lender Connections</span>
                </li>
              </ul>
            </div>
            
            <div className="mt-auto">
              <Button 
                onClick={() => handleSubscribe("Premium")}
                className="w-full rounded-none h-12 bg-yellow-500 hover:bg-yellow-600 text-white font-medium"
                size="lg"
              >
                Select Gold Premium →
              </Button>
            </div>
          </div>
        </div>
        
        <DialogFooter className="flex justify-between items-center px-6 pb-6 pt-0">
          <p className="text-sm text-muted-foreground">
            All plans include a 7-day money-back guarantee.
          </p>
          <Button 
            variant="ghost" 
            onClick={() => {
              localStorage.setItem("isLoggedIn", "true");
              navigate("/dashboard");
              onOpenChange(false);
            }}
          >
            Skip for now
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SubscriptionModal;
