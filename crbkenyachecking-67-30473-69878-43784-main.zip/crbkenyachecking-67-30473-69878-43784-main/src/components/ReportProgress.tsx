
import React, { useEffect, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Shield, LoaderCircle } from "lucide-react";

interface ReportProgressProps {
  open: boolean;
  onComplete: () => void;
}

const ReportProgress: React.FC<ReportProgressProps> = ({ open, onComplete }) => {
  const [progress, setProgress] = useState(0);
  
  useEffect(() => {
    if (!open) {
      setProgress(0);
      return;
    }
    
    // Start the progress simulation
    const interval = setInterval(() => {
      setProgress((prevProgress) => {
        if (prevProgress >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            onComplete();
          }, 500); // Small delay after reaching 100%
          return 100;
        }
        
        // Random increment between 1-5%
        const increment = Math.floor(Math.random() * 5) + 1;
        return Math.min(prevProgress + increment, 100);
      });
    }, 120); // Update every 120ms for a smooth but not too slow animation
    
    return () => clearInterval(interval);
  }, [open, onComplete]);
  
  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:rounded-lg border-0" hideCloseButton>
        <div className="flex flex-col items-center justify-center py-6 space-y-6">
          <div className="rounded-full bg-blue-100 p-4">
            <Shield className="h-12 w-12 text-blue-500" />
          </div>
          
          <div className="space-y-2 w-full">
            <h3 className="text-xl font-semibold text-center">Generating Your CRB Report</h3>
            <p className="text-muted-foreground text-center">Please wait while we process your report...</p>
          </div>
          
          <div className="w-full space-y-5 flex flex-col items-center">
            {/* Circular progress indicator with percentage in the middle */}
            <div className="relative w-16 h-16">
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <circle
                  className="text-blue-100 stroke-current"
                  strokeWidth="10"
                  cx="50"
                  cy="50"
                  r="40"
                  fill="transparent"
                ></circle>
                <circle
                  className="text-primary stroke-current"
                  strokeWidth="10"
                  strokeLinecap="round"
                  cx="50"
                  cy="50"
                  r="40"
                  fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 40}`}
                  strokeDashoffset={`${2 * Math.PI * 40 * (1 - progress / 100)}`}
                  style={{
                    transition: 'stroke-dashoffset 0.3s ease',
                    transformOrigin: 'center',
                    transform: 'rotate(-90deg)',
                  }}
                ></circle>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-primary font-medium text-sm">{progress}%</span>
              </div>
            </div>
            
            <div className="text-sm text-muted-foreground">
              <span>Processing...</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ReportProgress;
