
import React from "react";
import { Loader, Check } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface PaymentProcessingProps {
  isApproved: boolean;
  paymentStatus: string | null;
  progressValue: number;
}

const PaymentProcessing: React.FC<PaymentProcessingProps> = ({
  isApproved,
  paymentStatus,
  progressValue,
}) => {
  if (isApproved) {
    return (
      <div className="flex flex-col items-center justify-center space-y-6 py-8">
        <div className="rounded-full bg-green-100 p-4">
          <Check className="h-8 w-8 text-green-500" />
        </div>
        
        <div className="space-y-2 text-center">
          <h3 className="text-xl font-semibold">Access Granted!</h3>
          <p className="text-gray-600">
            Your payment has been approved. You now have full access to your CRB report.
          </p>
        </div>
        
        <div className="w-full space-y-2">
          <Progress value={progressValue} className="w-full" />
          <p className="text-xs text-right text-gray-500">Redirecting to dashboard...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col items-center justify-center space-y-6 py-8">
      <div className="rounded-full bg-blue-100 p-4">
        <Loader className="h-8 w-8 text-blue-500 animate-spin" />
      </div>
      
      <div className="space-y-3 text-center">
        <h3 className="text-xl font-semibold">Awaiting M-Pesa Confirmation</h3>
        <div className="space-y-2">
          <p className="text-gray-600">
            A prompt has been sent to your M-Pesa. Please check your phone and enter your M-Pesa PIN to complete the payment.
          </p>
          <p className="text-sm text-gray-500">
            Don't close this page. This page will update automatically once confirmed.
          </p>
        </div>
      </div>
      
      <div className="w-full space-y-2">
        <Progress value={progressValue} className="w-full" />
      </div>
    </div>
  );
};

export default PaymentProcessing;
