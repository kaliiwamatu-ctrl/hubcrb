import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Facebook, Twitter, Instagram, MessageSquare, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

const Footer = () => {
  const navigate = useNavigate();

  const handleContactClick = () => {
    navigate("/contact");
    
    // Allow some time for navigation before attempting to access DOM elements
    setTimeout(() => {
      const contactButton = document.querySelector("[data-contact-trigger]");
      if (contactButton && contactButton instanceof HTMLElement) {
        contactButton.click();
      }
    }, 100);
  };

  return (
    <footer className="bg-gradient-to-br from-primary to-secondary text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <img 
                src="/lovable-uploads/7a0ade53-bf0f-4426-988e-e159cf7606d6.png" 
                alt="CRB Checker Logo" 
                className="h-8 w-auto logo-image"
              />
              <span className="text-xl font-bold">Metropol CRB Checker</span>
            </div>
            <p className="text-gray-100 mb-4">
              Kenya's leading CRB status verification platform. Get your credit report and improve your financial standing.
            </p>
            <div className="flex space-x-4">
              <a href="https://facebook.com" className="text-white/70 hover:text-white transition">
                <div className="bg-white/10 hover:bg-white/20 p-2 rounded-full">
                  <Facebook size={18} />
                </div>
              </a>
              <a href="https://twitter.com" className="text-white/70 hover:text-white transition">
                <div className="bg-white/10 hover:bg-white/20 p-2 rounded-full">
                  <Twitter size={18} />
                </div>
              </a>
              <a href="https://instagram.com" className="text-white/70 hover:text-white transition">
                <div className="bg-white/10 hover:bg-white/20 p-2 rounded-full">
                  <Instagram size={18} />
                </div>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-white/20 pb-2">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-100 hover:text-white flex items-center transition">
                  <span className="h-1 w-1 bg-accent rounded-full mr-2"></span>
                  Home
                </Link>
              </li>
              <li>
                <Link to="/features" className="text-gray-100 hover:text-white flex items-center transition">
                  <span className="h-1 w-1 bg-accent rounded-full mr-2"></span>
                  Features
                </Link>
              </li>
              <li>
                <Link to="/reviews" className="text-gray-100 hover:text-white flex items-center transition">
                  <span className="h-1 w-1 bg-accent rounded-full mr-2"></span>
                  Reviews
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-100 hover:text-white flex items-center transition">
                  <span className="h-1 w-1 bg-accent rounded-full mr-2"></span>
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-gray-100 hover:text-white flex items-center transition">
                  <span className="h-1 w-1 bg-accent rounded-full mr-2"></span>
                  Terms & Conditions
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-white/20 pb-2">Services</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/signup" className="text-gray-100 hover:text-white flex items-center transition">
                  <span className="h-1 w-1 bg-accent rounded-full mr-2"></span>
                  CRB Status Check
                </Link>
              </li>
              <li>
                <Link to="/signup" className="text-gray-100 hover:text-white flex items-center transition">
                  <span className="h-1 w-1 bg-accent rounded-full mr-2"></span>
                  Credit Score
                </Link>
              </li>
              <li>
                <Link to="/signup" className="text-gray-100 hover:text-white flex items-center transition">
                  <span className="h-1 w-1 bg-accent rounded-full mr-2"></span>
                  Detailed Credit Report
                </Link>
              </li>
              <li>
                <Link to="/signup" className="text-gray-100 hover:text-white flex items-center transition">
                  <span className="h-1 w-1 bg-accent rounded-full mr-2"></span>
                  Credit Repair
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-white/20 pb-2">Contact Us</h3>
            <div className="mt-4 space-y-3">
              <Button
                variant="outline"
                className="text-white border-white/30 hover:bg-white/10 flex items-center space-x-2 w-full justify-start glass-morphism"
                onClick={handleContactClick}
              >
                <div className="bg-accent rounded-full p-1">
                  <MessageSquare size={16} className="text-white" />
                </div>
                <span>Send us a message</span>
              </Button>
              
              <a 
                href="mailto:support@metropolcrbchecker.co.ke" 
                className="text-white border border-white/30 hover:bg-white/10 rounded-md px-4 py-2 flex items-center space-x-2 w-full max-w-full break-words font-semibold glass-morphism"
                style={{ minWidth: "auto" }}
              >
                <Mail size={18} />
                <span>support@metropolcrbchecker.co.ke</span>
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/20 mt-10 pt-6 text-center text-white/70 text-sm">
          <p>&copy; {new Date().getFullYear()} Metropol CRB Checker. All rights reserved. <Link to="/terms" className="underline hover:text-white transition-colors">Terms & Conditions</Link> | <Link to="/privacy" className="underline hover:text-white transition-colors">Privacy Policy</Link></p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
