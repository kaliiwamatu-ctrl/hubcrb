
import React, { useEffect, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Check, Crown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import PaymentModal from "./PaymentModal";
import { useIsMobile } from "@/hooks/use-mobile";

interface CustomSubscriptionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  forceOpen?: boolean;
}

const CustomSubscriptionModal: React.FC<CustomSubscriptionModalProps> = ({ 
  open, 
  onOpenChange, 
  forceOpen = false 
}) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [standardPrice, setStandardPrice] = useState(0);
  const [premiumPrice, setPremiumPrice] = useState(0);
  const [userName, setUserName] = useState("");
  const [userId, setUserId] = useState("");
  const [showPayment, setShowPayment] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState(0);
  const [selectedPlan, setSelectedPlan] = useState("");

  useEffect(() => {
    if (open || forceOpen) {
      // Generate random prices within the specified ranges
      const randomStandardPrice = Math.floor(Math.random() * (175 - 140 + 1)) + 140;
      const randomPremiumPrice = Math.floor(Math.random() * (250 - 180 + 1)) + 180;
      
      setStandardPrice(randomStandardPrice);
      setPremiumPrice(randomPremiumPrice);
      
      // Get user info from localStorage - retrieve the exact ID used during registration
      const storedName = localStorage.getItem("userName") || "User";
      const storedId = localStorage.getItem("userId") || "";
      
      setUserName(storedName);
      setUserId(storedId);
    }
  }, [open, forceOpen]);

  const handleSubscribe = (plan: string, price: number) => {
    setSelectedPlan(plan);
    setSelectedAmount(price);
    setShowPayment(true);
  };

  const handlePaymentComplete = () => {
    localStorage.setItem("subscriptionPlan", selectedPlan);
    localStorage.setItem("isSubscribed", "true");
    
    toast({
      title: "Subscription Successful!",
      description: `You've subscribed to the ${selectedPlan} plan.`,
      variant: "default",
    });
    
    setShowPayment(false);
    onOpenChange(false);
    
    navigate("/dashboard");
  };

  return (
    <>
      <Dialog 
        open={open || forceOpen} 
        onOpenChange={onOpenChange}
      >
        <DialogContent className="sm:max-w-3xl p-0 overflow-hidden max-h-[90vh] overflow-y-auto w-full sm:w-[calc(100%-24px)] max-w-full sm:max-w-[calc(100%-24px)] mx-auto">
          <div className="p-4 sm:p-6 text-center border-b sticky top-0 bg-white z-10">
            <h2 className="text-xl sm:text-2xl font-bold">Hello {userName.toUpperCase()}</h2>
            <p className="text-muted-foreground text-sm sm:text-base break-words">ID Number: {userId}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 p-4 sm:p-6">
            {/* Standard Report */}
            <div className="border rounded-lg overflow-hidden flex flex-col h-full">
              <div className="p-4 sm:p-6 flex-grow">
                <h3 className="text-lg sm:text-xl font-bold">Standard Report</h3>
                <p className="text-muted-foreground mb-3 sm:mb-4 text-sm">Basic credit information</p>
                
                <div className="text-2xl sm:text-3xl font-bold mb-4 sm:mb-6">
                  KES {standardPrice}
                  <span className="text-xs sm:text-sm font-normal text-muted-foreground"> One-time payment</span>
                </div>
                
                <ul className="space-y-2 sm:space-y-3 text-left mb-4 sm:mb-6 text-sm sm:text-base">
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>Credit Score Analysis</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>Payment History Overview</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>Credit Utilization Report</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>Basic Recommendations</span>
                  </li>
                </ul>
              </div>
              
              <div className="p-3 sm:p-4 bg-gray-50 mt-auto">
                <Button 
                  className="w-full bg-purple-500 hover:bg-purple-600 h-10 sm:h-12"
                  onClick={() => handleSubscribe("Standard", standardPrice)}
                >
                  Select Standard <span className="ml-1">→</span>
                </Button>
              </div>
            </div>
            
            {/* Gold Premium */}
            <div className="border rounded-lg overflow-hidden border-yellow-200 bg-yellow-50/30 relative flex flex-col h-full">
              <div className="absolute top-0 right-0 bg-yellow-500 text-white px-2 sm:px-3 py-0.5 sm:py-1 text-xs rounded-bl-lg font-medium">
                RECOMMENDED
              </div>
              
              <div className="p-4 sm:p-6 flex-grow">
                <div className="flex items-center space-x-2">
                  <Crown className="h-4 w-4 sm:h-5 sm:w-5 text-yellow-500" />
                  <h3 className="text-lg sm:text-xl font-bold">Gold Premium</h3>
                </div>
                <p className="text-muted-foreground mb-3 sm:mb-4 text-sm">Enhanced credit insights</p>
                
                <div className="text-2xl sm:text-3xl font-bold mb-4 sm:mb-6">
                  KES {premiumPrice}
                  <span className="text-xs sm:text-sm font-normal text-muted-foreground"> One-time payment</span>
                </div>
                
                <ul className="space-y-2 sm:space-y-3 text-left mb-4 sm:mb-6 text-sm sm:text-base">
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>All Standard Features</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>Loan Application Matches</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>Credit Score Simulator</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>Personalized Improvement Plan</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>Monthly Score Updates</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mr-1.5 sm:mr-2 flex-shrink-0 mt-0.5" />
                    <span>Direct Lender Connections</span>
                  </li>
                </ul>
              </div>
              
              <div className="p-3 sm:p-4 bg-yellow-50 mt-auto">
                <Button 
                  className="w-full bg-yellow-500 hover:bg-yellow-600 text-white h-10 sm:h-12"
                  onClick={() => handleSubscribe("Gold Premium", premiumPrice)}
                >
                  Select Gold Premium <span className="ml-1">→</span>
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <PaymentModal 
        open={showPayment}
        onOpenChange={setShowPayment}
        amount={selectedAmount}
        onPaymentComplete={handlePaymentComplete}
      />
    </>
  );
};

export default CustomSubscriptionModal;
