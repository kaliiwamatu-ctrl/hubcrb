
import React, { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader, Shield, Check } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";

interface PaymentSubmissionProps {
  isSubmitting: boolean;
  mpesaMessage: string;
  onMessageChange: (message: string) => void;
  onSubmit: () => void;
}

const PaymentSubmission: React.FC<PaymentSubmissionProps> = ({
  isSubmitting,
  mpesaMessage,
  onMessageChange,
  onSubmit,
}) => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleSubmit = () => {
    setIsSubmitted(true);
    onSubmit();
  };
  
  if (isSubmitted || isSubmitting) {
    return (
      <div className="py-8 text-center">
        <div className="flex justify-center mb-4">
          <Shield className="h-12 w-12 text-blue-500" />
        </div>
        
        <h2 className="text-xl font-semibold mb-4">
          Thank you for submitting your payment
        </h2>
        
        <p className="text-gray-600 mb-6">
          Please wait as we are verifying your payment
        </p>
        
        <div className="flex justify-center items-center space-x-2 mb-6">
          <Loader className="h-5 w-5 text-blue-500 animate-spin" />
          <span className="text-blue-500 font-medium">
            Please wait, we are verifying payment
          </span>
        </div>
        
        <Progress value={40} className="h-2 mb-8" />
        
        <div className="space-y-4 mb-6">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-8 w-3/4 mx-auto" />
        </div>
      </div>
    );
  }

  return (
    <div className="mt-6">
      <Label htmlFor="mpesa-message">Full M-PESA Message</Label>
      <Textarea
        id="mpesa-message"
        className="min-h-[100px] mt-1"
        value={mpesaMessage}
        onChange={(e) => onMessageChange(e.target.value)}
      />
      <p className="text-xs text-gray-500 mt-1">
        Copy and paste the entire M-PESA confirmation message you received
      </p>
      
      <Button 
        className="w-full mt-6 bg-purple-500 hover:bg-purple-600"
        onClick={handleSubmit}
        disabled={isSubmitting || !mpesaMessage.trim()}
      >
        {isSubmitting ? (
          <>
            <Loader className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          "Submit Payment"
        )}
      </Button>
    </div>
  );
};

export default PaymentSubmission;
