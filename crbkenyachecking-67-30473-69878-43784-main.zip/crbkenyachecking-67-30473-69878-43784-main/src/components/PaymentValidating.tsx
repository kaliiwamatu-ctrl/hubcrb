
import React, { useState, useEffect } from "react";
import { Loader, CheckCircle, AlertCircle, FileUp, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";

interface PaymentValidatingProps {
  isUploadSuccess?: boolean;
  onRetry?: () => void;
  onManualVerification?: () => void;
  hasClickedVerify?: boolean;
  showTimeoutScreen?: boolean;
}

const PaymentValidating: React.FC<PaymentValidatingProps> = ({
  isUploadSuccess = false,
  onRetry,
  onManualVerification,
  hasClickedVerify = false,
  showTimeoutScreen = false
}) => {
  const [isTimedOut, setIsTimedOut] = useState(false);
  const [progressValue, setProgressValue] = useState(0);
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [userName, setUserName] = useState("Guest");
  const [showVerifyingScreen, setShowVerifyingScreen] = useState(false);
  const [showManualVerification, setShowManualVerification] = useState(false);
  const [showUploadSuccessScreen, setShowUploadSuccessScreen] = useState(false);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  
  useEffect(() => {
    // Get username from localStorage if available
    const storedName = localStorage.getItem("userName");
    if (storedName) {
      setUserName(storedName.split(' ')[0]); // Just get the first name
    }
    
    // If we're showing the timeout screen directly, set the timeout state
    if (showTimeoutScreen) {
      setIsTimedOut(true);
      return;
    }
    
    // If the user has already clicked verify once before, show manual verification UI immediately
    if (hasClickedVerify) {
      return; // Skip the timeout/progress logic
    }
    
    // Only start the timer if we're not already showing upload success or verify again screen
    if (isUploadSuccess || showVerifyingScreen || showManualVerification) return;
    
    const timerInterval = setInterval(() => {
      setProgressValue(prev => {
        // Increase progressively to 80% over 18 seconds
        const newValue = prev + (100 / 36);
        return newValue > 80 ? 80 : newValue;
      });
    }, 500);
    
    // Set timeout to trigger after 20 seconds
    const timeoutTimer = setTimeout(() => {
      setIsTimedOut(true);
      setProgressValue(80); // Freeze progress at 80%
      clearInterval(timerInterval);
    }, 20000);
    
    return () => {
      clearInterval(timerInterval);
      clearTimeout(timeoutTimer);
    };
  }, [isUploadSuccess, hasClickedVerify, showTimeoutScreen, showVerifyingScreen, showManualVerification]);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setReceiptFile(e.target.files[0]);
    }
  };
  
  const handleUpload = () => {
    // Show upload success screen
    setShowUploadSuccessScreen(true);
    
    // Start progress animation - adjusted for 20 minutes (1200 seconds)
    // Total time = 1200 seconds = 20 minutes
    // We increment by a small fraction each time to complete in 20 minutes
    setProgressValue(0);
    
    // Calculate increment per step
    // For 20 minutes (1200 seconds), with an update every 500ms
    // Total steps = 1200 * 2 = 2400 steps (500ms = 0.5s, so 2 steps per second)
    // Increment per step = 100 / 2400 = ~0.042 (rounded)
    const incrementPerStep = 0.042;
    
    const progressInterval = setInterval(() => {
      setProgressValue(prev => {
        const newValue = prev + incrementPerStep;
        if (newValue >= 100) {
          clearInterval(progressInterval);
          if (onManualVerification) {
            setTimeout(() => {
              onManualVerification();
            }, 1500); // Call the manual verification callback after showing success for a moment
          }
          return 100;
        }
        return newValue;
      });
    }, 500); // Update every 500ms for smoother animation
    
    // Clean up the interval if component unmounts
    return () => clearInterval(progressInterval);
  };

  const handleClose = () => {
    if (onRetry) {
      onRetry();
    }
  };
  
  const handleTryAgain = () => {
    toast({
      title: "Retry initiated",
      description: "Restarting verification process...",
    });
    
    // Show verifying screen first
    setShowVerifyingScreen(true);
    setIsTimedOut(false);
    setProgressValue(0);
    setShowManualVerification(false);
    
    // Start progress animation
    let progress = 0;
    const progressInterval = setInterval(() => {
      progress += 2;
      setProgressValue(prev => {
        const newValue = prev + 2;
        return newValue > 100 ? 100 : newValue;
      });
      
      if (progress >= 100) {
        clearInterval(progressInterval);
      }
    }, 500);
    
    // After 25 seconds, show manual verification screen
    setTimeout(() => {
      setShowVerifyingScreen(false);
      setShowManualVerification(true);
      clearInterval(progressInterval);
    }, 25000);
  };
  
  // If upload success screen is showing
  if (showUploadSuccessScreen) {
    return (
      <div className="flex flex-col items-center justify-center py-6 sm:py-8 space-y-3 sm:space-y-4 text-center px-3 sm:px-4">
        <h2 className="text-xl sm:text-2xl font-bold">Verifying Payment</h2>
        
        <div className="relative py-4">
          <Loader className="h-12 w-12 sm:h-16 sm:w-16 text-purple-500 animate-spin" />
        </div>
        
        <p className="text-lg sm:text-xl text-gray-700 max-w-xs font-medium">
          Please wait while we verify your payment details...
        </p>
        
        <div className="w-full max-w-sm mx-auto mt-4 sm:mt-6">
          <div className="h-2 sm:h-3 w-full bg-gradient-to-r from-purple-500 via-violet-500 to-blue-500 rounded-full overflow-hidden">
            <div
              className="h-full bg-white/30 animate-pulse"
              style={{ width: `${progressValue}%` }}
            />
          </div>
        </div>
      </div>
    );
  }
  
  // If showVerifyingScreen is true, show the verifying payment screen
  if (showVerifyingScreen) {
    return (
      <div className="flex flex-col items-center justify-center py-6 sm:py-8 space-y-3 sm:space-y-4 text-center px-3 sm:px-4">
        <h2 className="text-lg sm:text-xl font-semibold">Verifying Payment</h2>
        
        <div className="relative">
          <Loader className="h-10 w-10 sm:h-12 sm:w-12 text-purple-500 animate-spin" />
        </div>
        
        <p className="text-xs sm:text-sm text-gray-600 max-w-xs">
          Please wait while we verify your payment details...
        </p>
        
        <div className="w-full max-w-xs mx-auto mt-2 sm:mt-4">
          <Progress value={progressValue} className="h-1.5 sm:h-2 w-full" />
        </div>
      </div>
    );
  }
  
  // If showManualVerification is true, show manual verification screen
  if (showManualVerification) {
    return (
      <div className="flex flex-col py-3 sm:py-4 space-y-3 sm:space-y-4 px-2 sm:px-4">
        <h2 className="text-base sm:text-lg font-semibold text-yellow-500 text-center">Auto Authentication Failed</h2>
        
        <p className="text-xs sm:text-sm text-gray-600 text-center py-1.5 sm:py-2.5 px-1 sm:px-2 break-words">
          Hello Dear {userName},
          <br /><br className="hidden sm:block" />
          Automatic Authentication failed. Please wait as we verify your payment Manually. 
          You will receive a notification immediately to access your account 
          after we have verified your payment. It takes few 
          minutes. Please attach payment receipt or 
          screenshot of your Mpesa payment.
        </p>
        
        <div className="space-y-2 sm:space-y-3">
          <div className="flex flex-col space-y-1 sm:space-y-2">
            <label className="text-xs sm:text-sm font-medium">Upload Payment Receipt</label>
            <Input
              type="file"
              accept=".jpg,.jpeg,.png,.pdf"
              className="cursor-pointer text-xs py-1 sm:py-1.5 break-words overflow-hidden text-ellipsis"
              onChange={handleFileChange}
            />
            <p className="text-[10px] sm:text-xs text-gray-500">
              Accepted formats: JPG, PNG, PDF (Max 5MB)
            </p>
          </div>
          
          <Button 
            onClick={handleUpload} 
            className="w-full bg-purple-600 hover:bg-purple-700 py-3 sm:py-4 flex items-center justify-center gap-1.5 sm:gap-2 text-xs sm:text-sm"
            disabled={!receiptFile}
            size={isMobile ? "sm" : "default"}
          >
            <FileUp className="h-3 w-3 sm:h-4 sm:w-4" />
            Upload Receipt
          </Button>
          
          <Button
            variant="secondary"
            onClick={handleClose}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 sm:py-4 text-xs sm:text-sm"
            size={isMobile ? "sm" : "default"}
          >
            Close
          </Button>
        </div>
      </div>
    );
  }

  // If showTimeoutScreen prop is true or isTimedOut is true, show the timeout screen
  if (showTimeoutScreen || isTimedOut) {
    return (
      <div className="flex flex-col items-center justify-center py-6 sm:py-8 space-y-3 sm:space-y-4 text-center px-3 sm:px-4">
        <div className="h-8 w-8 sm:h-12 sm:w-12 flex items-center justify-center">
          <AlertCircle className="h-8 w-8 sm:h-12 sm:w-12 text-amber-500" />
        </div>
        <h2 className="text-lg sm:text-xl font-semibold text-amber-600">Verification Timeout</h2>
        <p className="text-xs sm:text-sm text-gray-600 max-w-xs">
          It has taken too long than expected. Please try again.
        </p>
        <Button 
          className="bg-purple-500 hover:bg-purple-600 flex items-center gap-1.5 py-2 px-3 text-xs sm:text-sm"
          onClick={handleTryAgain}
          size={isMobile ? "sm" : "default"}
        >
          <RefreshCw className="h-3 w-3 sm:h-4 sm:w-4" />
          Try Again
        </Button>
      </div>
    );
  }
  
  if (isUploadSuccess) {
    return (
      <div className="flex flex-col items-center justify-center py-6 sm:py-8 space-y-3 sm:space-y-4 text-center px-3 sm:px-4">
        <div className="h-8 w-8 sm:h-12 sm:w-12 flex items-center justify-center">
          <CheckCircle className="h-8 w-8 sm:h-12 sm:w-12 text-green-500" />
        </div>
        <h2 className="text-lg sm:text-xl font-semibold text-green-600">Upload Successful</h2>
        <p className="text-xs sm:text-sm text-gray-600 max-w-xs break-words">
          Your Payment receipt Uploaded Successfully. Please wait for Verification.
        </p>
      </div>
    );
  }
  
  // Default view: loading state
  return (
    <div className="flex flex-col items-center justify-center py-6 sm:py-8 space-y-3 sm:space-y-4 text-center px-3 sm:px-4">
      <h2 className="text-lg sm:text-xl font-semibold">Verifying Payment</h2>
      
      <div className="relative">
        <Loader className="h-10 w-10 sm:h-12 sm:w-12 text-purple-500 animate-spin" />
      </div>
      
      <p className="text-xs sm:text-sm text-gray-600 max-w-xs">
        Please wait while we verify your payment details...
      </p>
      
      <div className="w-full max-w-xs mx-auto mt-2 sm:mt-4">
        <Progress value={progressValue} className="h-1.5 sm:h-2 w-full" />
      </div>
    </div>
  );
};

export default PaymentValidating;
