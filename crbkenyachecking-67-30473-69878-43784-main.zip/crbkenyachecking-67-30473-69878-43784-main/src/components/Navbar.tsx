
import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  MenuIcon,
  X,
  UserCircle,
} from "lucide-react";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle
} from "@/components/ui/navigation-menu";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  
  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";

  return (
    <nav className="bg-gradient-to-r from-primary via-primary/90 to-primary/70 shadow-lg sticky top-0 z-50 border-b border-white/20 glass-morphism">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-3 group">
            <img 
              src="/lovable-uploads/7a0ade53-bf0f-4426-988e-e159cf7606d6.png" 
              alt="CRB Checker Logo" 
              className="h-10 w-auto transform transition-transform group-hover:scale-105 logo-image"
            />
            <span className="text-xl font-bold text-white drop-shadow-sm">Metropol CRB Checker</span>
          </Link>
          
          {/* Desktop navigation */}
          <div className="hidden md:flex items-center">
            <NavigationMenu className="text-white mr-4">
              <NavigationMenuList className="space-x-1">
                <NavigationMenuItem>
                  <Link to="/">
                    <NavigationMenuLink
                      className={`${navigationMenuTriggerStyle()} text-white hover:bg-white/20 backdrop-blur-sm ${location.pathname === "/" ? "bg-white/20 shadow-sm" : ""}`}
                    >
                      Home
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/features">
                    <NavigationMenuLink
                      className={`${navigationMenuTriggerStyle()} text-white hover:bg-white/20 backdrop-blur-sm ${location.pathname === "/features" ? "bg-white/20 shadow-sm" : ""}`}
                    >
                      Features
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/reviews">
                    <NavigationMenuLink
                      className={`${navigationMenuTriggerStyle()} text-white hover:bg-white/20 backdrop-blur-sm ${location.pathname === "/reviews" ? "bg-white/20 shadow-sm" : ""}`}
                    >
                      Reviews
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/faq">
                    <NavigationMenuLink
                      className={`${navigationMenuTriggerStyle()} text-white hover:bg-white/20 backdrop-blur-sm ${location.pathname === "/faq" ? "bg-white/20 shadow-sm" : ""}`}
                    >
                      FAQ
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link to="/contact">
                    <NavigationMenuLink
                      className={`${navigationMenuTriggerStyle()} text-white hover:bg-white/20 backdrop-blur-sm ${location.pathname === "/contact" ? "bg-white/20 shadow-sm" : ""}`}
                    >
                      Contact
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
            
            <div className="flex items-center space-x-3">
              {isLoggedIn ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="flex items-center space-x-2 bg-white/20 hover:bg-white/30 text-white border-white/20 shadow-md backdrop-blur-sm">
                      <UserCircle size={18} />
                      <span>Dashboard</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="backdrop-blur-md bg-white/95 border border-white/20 shadow-xl">
                    <DropdownMenuItem asChild className="hover:bg-primary/10">
                      <Link to="/dashboard" className="w-full">Dashboard</Link>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <>
                  <Link to="/login">
                    <Button className="px-5 bg-green-400 hover:bg-green-500 text-white font-medium shadow-md">Login</Button>
                  </Link>
                  <Link to="/signup">
                    <Button variant="accent" className="px-5 text-white font-medium hover:bg-accent/90 shadow-lg hover:shadow-xl transition-all transform hover:scale-105">Sign Up</Button>
                  </Link>
                </>
              )}
            </div>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-white p-2 bg-white/10 rounded-lg backdrop-blur-sm hover:bg-white/20"
            >
              {mobileMenuOpen ? <X size={24} /> : <MenuIcon size={24} />}
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-2 glass-morphism rounded-xl mt-3 border border-white/20 shadow-lg">
            <Link 
              to="/" 
              className={`block px-4 py-2.5 rounded-lg mx-2 ${location.pathname === "/" ? "bg-white/20 text-white shadow-md" : "text-white/95"}`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link 
              to="/features" 
              className={`block px-4 py-2.5 rounded-lg mx-2 ${location.pathname === "/features" ? "bg-white/20 text-white shadow-md" : "text-white/95"}`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Features
            </Link>
            <Link 
              to="/reviews" 
              className={`block px-4 py-2.5 rounded-lg mx-2 ${location.pathname === "/reviews" ? "bg-white/20 text-white shadow-md" : "text-white/95"}`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Reviews
            </Link>
            <Link 
              to="/faq" 
              className={`block px-4 py-2.5 rounded-lg mx-2 ${location.pathname === "/faq" ? "bg-white/20 text-white shadow-md" : "text-white/95"}`}
              onClick={() => setMobileMenuOpen(false)}
            >
              FAQ
            </Link>
            <Link 
              to="/contact" 
              className={`block px-4 py-2.5 rounded-lg mx-2 ${location.pathname === "/contact" ? "bg-white/20 text-white shadow-md" : "text-white/95"}`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Contact
            </Link>
            
            {isLoggedIn ? (
              <div className="space-y-2 pt-2 border-t border-white/20 mx-2 mt-3">
                <Link 
                  to="/dashboard"
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-2"
                >
                  <Button className="w-full flex items-center justify-center space-x-2 bg-white text-primary hover:bg-white/90 shadow-md">
                    <UserCircle size={18} />
                    <span>Dashboard</span>
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-2 pt-2 border-t border-white/20 mx-2 mt-3">
                <Link 
                  to="/login"
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-2"
                >
                  <Button className="w-full bg-green-400 hover:bg-green-500 text-white shadow-md">Login</Button>
                </Link>
                <Link 
                  to="/signup"
                  onClick={() => setMobileMenuOpen(false)} 
                  className="block px-2"
                >
                  <Button className="w-full bg-accent hover:bg-accent/90 text-white shadow-md">Sign Up</Button>
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
