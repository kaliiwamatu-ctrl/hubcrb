import React, { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Shield, Smartphone } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import PaymentProcessing from "@/components/PaymentProcessing";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface PaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  amount: number;
  onPaymentComplete: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({
  open,
  onOpenChange,
  amount,
  onPaymentComplete,
}) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressValue, setProgressValue] = useState(0);
  const [paymentId, setPaymentId] = useState<string | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<string | null>(null);
  const [isApproved, setIsApproved] = useState(false);
  const [checkingTimer, setCheckingTimer] = useState<NodeJS.Timeout | null>(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [userId, setUserId] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handlePaymentSubmit = async () => {
    if (!phoneNumber.trim()) {
      toast({
        title: "Phone number required",
        description: "Please enter your M-PESA phone number",
        variant: "destructive",
      });
      return;
    }

    // Validate phone number format
    const phoneRegex = /^(?:254|0)?[71]\d{8}$/;
    if (!phoneRegex.test(phoneNumber.replace(/\s+/g, ''))) {
      toast({
        title: "Invalid phone number",
        description: "Please enter a valid Kenyan phone number (e.g., 0712345678 or 254712345678)",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();

      console.log('Initiating PayHero payment:', {
        amount,
        phoneNumber: phoneNumber.replace(/\s+/g, ''),
        userId: user?.id || userId,
      });

      setIsProcessing(true);

      // Call edge function to handle payment and transaction creation
      const { data, error } = await supabase.functions.invoke('payhero-stk-push', {
        body: {
          amount: amount,
          phoneNumber: phoneNumber.replace(/\s+/g, ''),
          userId: user?.id || userId,
          packageType: amount === 158 ? 'Standard' : 'Gold Premium',
        },
      });

      console.log('PayHero edge function response:', { data, error });

      if (error) {
        console.error('Edge function error:', error);
        throw new Error(error.message || 'Payment initiation failed');
      }

      if (data?.error) {
        console.error('PayHero API error:', data.error);
        throw new Error(data.error || 'Payment initiation failed');
      }

      // Store the transaction ID from the response
      if (data?.transactionId) {
        setPaymentId(data.transactionId);
      }

      toast({
        title: "STK Push sent",
        description: "Please check your phone and enter your M-PESA PIN to complete the payment",
      });

      startProgressSimulation(30);
      startPaymentStatusCheck();

    } catch (error: any) {
      console.error("Error initiating payment:", error);

      toast({
        title: "Payment failed",
        description: error.message || "There was a problem initiating the payment. Please try again.",
        variant: "destructive",
      });

      setIsProcessing(false);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const startPaymentStatusCheck = () => {
    if (checkingTimer) clearInterval(checkingTimer);
    
    const timer = setInterval(async () => {
      if (!paymentId) return;
      
      try {
        const { data, error } = await supabase
          .from('payment_transactions')
          .select('status')
          .eq('id', paymentId)
          .single();
          
        if (error) {
          console.error("Error checking payment status:", error);
          return;
        }
        
        if (data) {
          setPaymentStatus(data.status);
        
          if (data.status === 'approved' && !isApproved) {
            setIsApproved(true);
            handlePaymentApproved();
            
            clearInterval(timer);
            setCheckingTimer(null);
          }
        }
      } catch (error) {
        console.error("Error checking payment status:", error);
      }
    }, 3000);
    
    setCheckingTimer(timer);
  };
  
  const handlePaymentApproved = () => {
    setProgressValue(100);
    
    localStorage.setItem("subscriptionPlan", "Standard");
    localStorage.setItem("isSubscribed", "true");
    
    toast({
      title: "Access granted",
      description: "You now have full access to CRB status",
    });
    
    onPaymentComplete();
    
    setTimeout(() => {
      onOpenChange(false);
      
      navigate("/dashboard");
    }, 2000);
  };

  const startProgressSimulation = (targetValue: number) => {
    setProgressValue(0);
    const interval = setInterval(() => {
      setProgressValue((prev) => {
        if (prev >= targetValue) {
          clearInterval(interval);
          return targetValue;
        }
        return prev + Math.random() * 3;
      });
    }, 30);
  };


  const resetPaymentForm = () => {
    setIsProcessing(false);
    setProgressValue(0);
    setPaymentId(null);
    setPaymentStatus(null);
    setIsApproved(false);
    setPhoneNumber("");
    if (checkingTimer) {
      clearInterval(checkingTimer);
      setCheckingTimer(null);
    }
  };

  useEffect(() => {
    // Get user ID from localStorage
    const storedUserId = localStorage.getItem("userId") || "";
    setUserId(storedUserId);
    
    return () => {
      if (checkingTimer) clearInterval(checkingTimer);
    };
  }, []);

  useEffect(() => {
    if (open) {
      resetPaymentForm();
    }
  }, [open]);

  const renderContent = () => {
    if (isProcessing) {
      return (
        <PaymentProcessing 
          isApproved={isApproved}
          paymentStatus={paymentStatus}
          progressValue={progressValue}
        />
      );
    }

    return (
      <>
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-3 bg-primary/10 rounded-full">
            <Smartphone className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold">M-PESA Payment</h2>
            <p className="text-primary font-semibold">KSh {amount.toFixed(2)}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-blue-900 dark:text-blue-100">
              Enter your M-PESA phone number below. You will receive an STK push prompt on your phone to complete the payment.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">M-PESA Phone Number</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="e.g., 0712345678 or 254712345678"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className="text-lg"
              disabled={isSubmitting}
            />
            <p className="text-xs text-muted-foreground">
              Enter the phone number registered with M-PESA
            </p>
          </div>

          <Button 
            className="w-full"
            size="lg"
            onClick={handlePaymentSubmit}
            disabled={!phoneNumber.trim() || isSubmitting}
          >
            {isSubmitting ? "Sending STK Push..." : "Pay with M-PESA"}
          </Button>

          <div className="text-center">
            <Shield className="h-5 w-5 text-green-600 inline mr-2" />
            <span className="text-sm text-muted-foreground">
              Secure payment powered by PayHero
            </span>
          </div>
        </div>
      </>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        {renderContent()}
      </DialogContent>
    </Dialog>
  );
};

export default PaymentModal;
