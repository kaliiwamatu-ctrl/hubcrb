
export interface Payment {
  id: string;
  user_id: string | null;
  amount: number;
  status: string;
  created_at: string;
  updated_at: string;
  description: string | null;
  payment_method: string | null;
  transaction_reference: string | null;
  currency: string;
  
  // These fields are used in the component but not in the database
  // We'll add them here to maintain compatibility with existing code
  mpesa_message?: string;
  approved_at?: string | null;
  approved_by?: string | null;
  notes?: string | null;
}

export interface UserDetails {
  email: string;
}
