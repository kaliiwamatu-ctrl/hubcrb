
export const ensureUserData = () => {
  // Check if user data exists in localStorage and set defaults if not
  if (!localStorage.getItem("userName")) {
    localStorage.setItem("userName", "Kim");
  }
  
  if (!localStorage.getItem("userId")) {
    localStorage.setItem("userId", "33111365");
  }
};
