
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import './hideBadge.css' // Import the CSS to hide Lovable badge

createRoot(document.getElementById("root")!).render(<App />);
