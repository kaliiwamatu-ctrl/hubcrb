
import React, { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart, 
  CheckCircle, 
  AlertCircle, 
  FileText, 
  Clock, 
  Download, 
  AlertTriangle,
  Wallet,
  RefreshCcw,
  User,
  CreditCard
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart as ReBarChart,
  Bar,
  Cell
} from "recharts";
import { Link } from "react-router-dom";

// Mock data
const scoreHistory = [
  { month: "Jan", score: 650 },
  { month: "Feb", score: 678 },
  { month: "Mar", score: 690 },
  { month: "Apr", score: 685 },
  { month: "May", score: 710 },
  { month: "Jun", score: 735 },
  { month: "Jul", score: 750 }
];

const creditAccounts = [
  { name: "Personal Loan", status: "Good Standing", balance: 150000, paid: 50000, lender: "Equity Bank" },
  { name: "Credit Card", status: "Good Standing", balance: 35000, paid: 30000, lender: "KCB Bank" },
  { name: "Mobile Loan", status: "Late Payment", balance: 10000, paid: 5000, lender: "M-Shwari" },
  { name: "Car Loan", status: "Good Standing", balance: 900000, paid: 350000, lender: "Co-operative Bank" },
];

const loanTypes = [
  { name: "Personal Loan", value: 40 },
  { name: "Credit Card", value: 25 },
  { name: "Mobile Loan", value: 10 },
  { name: "Car Loan", value: 25 },
];

const colors = ["#1C8A43", "#144E78", "#E67E22", "#9333ea"];

const Dashboard = () => {
  const userName = localStorage.getItem("userName") || "John Doe";
  const subscriptionPlan = localStorage.getItem("subscriptionPlan") || "Basic";
  
  const [currentTab, setCurrentTab] = useState("overview");
  
  const getCreditScore = () => {
    return scoreHistory[scoreHistory.length - 1].score;
  };
  
  const getCreditStatus = () => {
    const score = getCreditScore();
    if (score >= 700) return { text: "Excellent", color: "green-600" };
    if (score >= 650) return { text: "Good", color: "blue-600" };
    if (score >= 600) return { text: "Fair", color: "yellow-600" };
    return { text: "Poor", color: "red-600" };
  };
  
  const getScoreColor = () => {
    const score = getCreditScore();
    if (score >= 700) return "border-green-500 text-green-600";
    if (score >= 650) return "border-blue-500 text-blue-600";
    if (score >= 600) return "border-yellow-500 text-yellow-600";
    return "border-red-500 text-red-600";
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };
  
  const today = new Date();
  const nextMonth = new Date(today);
  nextMonth.setMonth(today.getMonth() + 1);
  
  const status = getCreditStatus();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-start justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">Welcome, {userName}</h1>
              <p className="text-gray-600">
                Here's the latest update on your credit status
              </p>
            </div>
            
            <div className="flex items-center mt-4 md:mt-0 space-x-2 bg-white rounded-lg shadow-sm p-3 border border-gray-100">
              <div className="px-3 py-1.5 bg-primary/10 text-primary rounded-md font-medium">
                {subscriptionPlan} Plan
              </div>
              <p className="text-gray-500 text-sm px-2">
                Next billing: {formatDate(nextMonth.toISOString())}
              </p>
              <Link to="/pricing">
                <Button size="sm" variant="outline">Upgrade</Button>
              </Link>
            </div>
          </div>
          
          <Tabs defaultValue="overview" value={currentTab} onValueChange={setCurrentTab} className="space-y-6">
            <TabsList className="grid grid-cols-3 md:w-[500px]">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
              <TabsTrigger value="accounts">Accounts</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Credit Score Card */}
                <Card className="md:col-span-1">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Credit Score</CardTitle>
                    <CardDescription>
                      Updated {formatDate(today.toISOString())}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col items-center">
                      <div className={`score-ring ${getScoreColor()} mb-4`}>
                        {getCreditScore()}
                      </div>
                      <div className={`text-${status.color} font-semibold text-lg`}>
                        {status.text}
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        Score range: 300-850
                      </p>
                      <Button className="mt-6 w-full" size="sm">
                        View Full Report
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Credit History Graph */}
                <Card className="md:col-span-2">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Score History</CardTitle>
                    <CardDescription>
                      How your credit score has changed over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[250px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={scoreHistory}
                          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#1C8A43" stopOpacity={0.8} />
                              <stop offset="95%" stopColor="#1C8A43" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <XAxis dataKey="month" />
                          <YAxis domain={[600, 850]} />
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <Tooltip />
                          <Area 
                            type="monotone" 
                            dataKey="score" 
                            stroke="#1C8A43" 
                            fillOpacity={1} 
                            fill="url(#scoreGradient)" 
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* CRB Status Card */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">CRB Status</CardTitle>
                    <CardDescription>Your current listing status</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-100">
                      <div className="flex items-center">
                        <CheckCircle className="h-10 w-10 text-green-500 mr-4" />
                        <div>
                          <h3 className="font-semibold text-green-700">Good Standing</h3>
                          <p className="text-sm text-green-600">No negative listings found</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="text-xs">
                        Details
                      </Button>
                    </div>
                    
                    <div className="mt-4">
                      <h4 className="font-medium mb-2">Credit Bureau Records</h4>
                      <div className="space-y-3">
                        {[
                          { bureau: "TransUnion", status: "Clear", icon: CheckCircle },
                          { bureau: "Metropol", status: "Clear", icon: CheckCircle },
                          { bureau: "Creditinfo", status: "Clear", icon: CheckCircle }
                        ].map((bureau) => (
                          <div key={bureau.bureau} className="flex items-center justify-between border-b pb-2">
                            <span>{bureau.bureau}</span>
                            <div className="flex items-center text-green-600">
                              <bureau.icon className="h-4 w-4 mr-1" />
                              <span className="text-sm font-medium">{bureau.status}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Loan Breakdown */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Credit Distribution</CardTitle>
                    <CardDescription>Breakdown of your credit accounts</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[200px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <ReBarChart data={loanTypes}>
                          <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                          <YAxis hide />
                          <Tooltip />
                          <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                            {loanTypes.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                            ))}
                          </Bar>
                        </ReBarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {loanTypes.map((type, index) => (
                        <div key={type.name} className="flex items-center">
                          <div 
                            className="w-3 h-3 rounded-full mr-2" 
                            style={{ backgroundColor: colors[index % colors.length] }}
                          ></div>
                          <span className="text-xs">{type.name}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                {/* Recent Activity */}
                <Card className="md:col-span-1">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Recent Activity</CardTitle>
                    <CardDescription>Latest updates to your credit profile</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          title: "Credit Score Updated",
                          description: "Your score increased by 15 points",
                          date: "Today",
                          icon: BarChart,
                          color: "text-green-500 bg-green-50"
                        },
                        {
                          title: "New Credit Inquiry",
                          description: "Equity Bank checked your credit",
                          date: "Yesterday",
                          icon: FileText,
                          color: "text-blue-500 bg-blue-50"
                        },
                        {
                          title: "Payment Warning",
                          description: "Mobile loan payment due in 3 days",
                          date: "2 days ago",
                          icon: AlertTriangle,
                          color: "text-yellow-500 bg-yellow-50"
                        },
                        {
                          title: "Account Paid",
                          description: "Credit card bill payment received",
                          date: "1 week ago",
                          icon: Wallet,
                          color: "text-green-500 bg-green-50"
                        }
                      ].map((activity, index) => (
                        <div key={index} className="flex items-start">
                          <div className={`p-2 rounded-full ${activity.color} mr-3`}>
                            <activity.icon className="h-4 w-4" />
                          </div>
                          <div>
                            <h4 className="font-medium text-sm">{activity.title}</h4>
                            <p className="text-xs text-gray-600">{activity.description}</p>
                            <p className="text-xs text-gray-400 mt-1">{activity.date}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <Button variant="ghost" className="w-full mt-4 text-xs">
                      View All Activity
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="reports">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Full Credit Report</CardTitle>
                    <CardDescription>
                      Comprehensive analysis of your credit history
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 border rounded-lg flex justify-between items-center">
                        <div className="flex items-center">
                          <FileText className="h-8 w-8 text-primary mr-4" />
                          <div>
                            <h3 className="font-medium">Standard Credit Report</h3>
                            <p className="text-sm text-gray-500">Updated today</p>
                          </div>
                        </div>
                        <Button>
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                      </div>
                      
                      <div className="p-4 border rounded-lg flex justify-between items-center">
                        <div className="flex items-center">
                          <Clock className="h-8 w-8 text-gray-400 mr-4" />
                          <div>
                            <h3 className="font-medium">Historical Report (2023)</h3>
                            <p className="text-sm text-gray-500">Last year's data</p>
                          </div>
                        </div>
                        <Button variant="outline">
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                      </div>
                      
                      <div className="p-4 border border-dashed rounded-lg flex justify-between items-center bg-gray-50">
                        <div className="flex items-center">
                          <AlertCircle className="h-8 w-8 text-yellow-500 mr-4" />
                          <div>
                            <h3 className="font-medium">Premium Analysis Report</h3>
                            <p className="text-sm text-gray-500">Upgrade to access</p>
                          </div>
                        </div>
                        <Button variant="secondary">
                          Upgrade
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Request New Reports</CardTitle>
                    <CardDescription>
                      Generate specialized credit reports
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          title: "Bank Loan Eligibility",
                          description: "Check if you qualify for bank loans",
                          icon: CreditCard,
                          available: true
                        },
                        {
                          title: "Credit Health Check",
                          description: "Detailed analysis of your credit status",
                          icon: RefreshCcw,
                          available: true
                        },
                        {
                          title: "Identity Verification",
                          description: "Verify your credit identity",
                          icon: User,
                          available: false
                        }
                      ].map((report, index) => (
                        <div key={index} className="p-4 border rounded-lg flex justify-between items-center">
                          <div className="flex items-center">
                            <report.icon className="h-6 w-6 text-primary mr-4" />
                            <div>
                              <h3 className="font-medium">{report.title}</h3>
                              <p className="text-sm text-gray-500">{report.description}</p>
                            </div>
                          </div>
                          <Button variant={report.available ? "default" : "secondary"}>
                            {report.available ? "Generate" : "Upgrade"}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="accounts">
              <Card>
                <CardHeader>
                  <CardTitle>Credit Accounts</CardTitle>
                  <CardDescription>
                    Active credit accounts linked to your profile
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {creditAccounts.map((account, index) => (
                      <div key={index} className="border rounded-lg p-5">
                        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                          <div>
                            <h3 className="font-semibold text-lg">{account.name}</h3>
                            <p className="text-sm text-gray-500">{account.lender}</p>
                          </div>
                          <div className={`px-3 py-1 rounded-full text-sm font-medium mt-2 md:mt-0 inline-flex items-center ${
                            account.status === "Good Standing" 
                              ? "bg-green-100 text-green-800" 
                              : "bg-yellow-100 text-yellow-800"
                          }`}>
                            {account.status === "Good Standing" ? (
                              <CheckCircle className="h-3 w-3 mr-1" />
                            ) : (
                              <AlertCircle className="h-3 w-3 mr-1" />
                            )}
                            {account.status}
                          </div>
                        </div>
                        
                        <div className="mt-4">
                          <div className="flex justify-between mb-1 text-sm">
                            <span>Paid: KSh {account.paid.toLocaleString()}</span>
                            <span>Total: KSh {account.balance.toLocaleString()}</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div 
                              className="bg-primary h-2.5 rounded-full" 
                              style={{ width: `${(account.paid / account.balance) * 100}%` }}
                            ></div>
                          </div>
                          <div className="mt-1 text-xs text-right text-gray-500">
                            {Math.round((account.paid / account.balance) * 100)}% paid
                          </div>
                        </div>
                        
                        <div className="mt-4 pt-4 border-t flex justify-end">
                          <Button variant="outline" size="sm" className="text-xs">
                            View Details
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Dashboard;
