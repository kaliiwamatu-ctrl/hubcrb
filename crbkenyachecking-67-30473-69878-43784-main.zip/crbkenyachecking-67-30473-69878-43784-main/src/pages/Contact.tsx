
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { MessageSquare, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useLocation } from "react-router-dom";

const Contact = () => {
  const [message, setMessage] = useState("");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [showDialog, setShowDialog] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);
  const { toast } = useToast();
  const location = useLocation();

  // Check if we need to open the contact form automatically
  // (when navigating from the footer button)
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    if (searchParams.has("openForm")) {
      setShowContactForm(true);
    }
  }, [location]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send this data to a server
    console.log({ name, email, message });
    
    // Show success dialog and toast
    setShowDialog(true);
    toast({
      title: "Message Sent",
      description: "We'll get back to you shortly!",
    });
    
    // Reset form and hide it
    setMessage("");
    setEmail("");
    setName("");
    setShowContactForm(false);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-primary/5 py-12 md:py-20">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Contact Us</h1>
              <p className="text-lg text-gray-600 mb-8">
                Have questions or need assistance? Send us a message and we'll get back to you as soon as possible.
              </p>
              <Button 
                onClick={() => setShowContactForm(!showContactForm)}
                size="lg"
                className="mx-auto flex items-center gap-2"
                data-contact-trigger
              >
                <MessageSquare className="h-5 w-5" color="#1C8A43" />
                Send us a message
              </Button>
            </div>
          </div>
        </section>
        
        {/* Chat Section - Hidden by default */}
        {showContactForm && (
          <section className="py-16">
            <div className="container mx-auto px-4">
              <div className="max-w-2xl mx-auto">
                <div className="bg-white shadow-lg rounded-lg overflow-hidden border">
                  <div className="p-6 bg-primary text-white flex items-center justify-between">
                    <div className="flex items-center">
                      <MessageSquare className="h-6 w-6 mr-3" />
                      <h2 className="text-xl font-semibold">Send us a message</h2>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => setShowContactForm(false)}
                      className="text-white hover:bg-primary/80"
                    >
                      <span className="sr-only">Close</span>
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                    </Button>
                  </div>
                  
                  <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Your Name
                      </label>
                      <Input
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Enter your name"
                        required
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Your Email
                      </label>
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email"
                        required
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                        Message
                      </label>
                      <Textarea
                        id="message"
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Type your message here..."
                        required
                        className="w-full min-h-[150px]"
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">
                      Send Message
                      <Send className="ml-2 h-4 w-4" />
                    </Button>
                  </form>
                </div>
              </div>
            </div>
          </section>
        )}
        
        {/* Success Dialog */}
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Message Sent Successfully!</DialogTitle>
              <DialogDescription>
                Thank you for reaching out. We've received your message and will get back to you shortly.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button onClick={() => setShowDialog(false)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
      
      <Footer />
    </div>
  );
};

export default Contact;
