import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowRight, Shield, Users, Award, CreditCard, FileCheck, Star } from "lucide-react";
import StatisticsCounter from "@/components/StatisticsCounter";

const Index = () => {
  const testimonials = [
    {
      name: "Peter Kamau",
      role: "Small Business Owner",
      image: "/lovable-uploads/52cc0e18-04dc-4075-b79b-e53e3768b76a.png",
      testimonial: "CRB Checker transformed my business loan journey! After clearing my listing, I secured funding for my shop expansion within just 2 weeks. Their step-by-step guidance was invaluable."
    },
    {
      name: "Mary Wanjiku",
      role: "Bank Employee",
      image: "/lovable-uploads/52cc0e18-04dc-4075-b79b-e53e3768b76a.png",
      testimonial: "As someone who works in banking, I'm impressed with CRB Checker's accuracy and speed. The platform helped me identify and resolve errors in my own listing that I wasn't even aware of!"
    },
    {
      name: "David Kiprotich",
      role: "Real Estate Agent",
      image: "/lovable-uploads/52cc0e18-04dc-4075-b79b-e53e3768b76a.png",
      testimonial: "I recommend CRB Checker to all my clients looking to qualify for mortgages. Their blacklist clearance service helped me close more deals by getting my clients loan-ready."
    }
  ];

  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 30000); // Change every 30 seconds

    return () => clearInterval(interval);
  }, [testimonials.length]);
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="hero-pattern py-20 md:py-32 relative overflow-hidden">
          <div className="container mx-auto px-4 relative z-10">
            <div className="flex flex-col md:flex-row items-center gap-12">
              <div className="md:w-1/2 mb-10 md:mb-0">
                <div className="inline-block px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-semibold mb-6">
                  🚀 Kenya's Leading Credit Platform
                </div>
                <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6 font-display">
                  Unlock Your <span className="gradient-text">Financial Freedom</span> 
                </h1>
                <p className="text-xl text-muted-foreground mb-8 leading-relaxed max-w-lg">
                  Transform your financial journey with instant CRB verification. Get real-time credit insights and unlock borrowing opportunities from top lending institutions.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link to="/signup">
                    <Button size="lg" className="text-lg">
                      Start Your Credit Check
                      <ArrowRight className="ml-2 h-6 w-6" />
                    </Button>
                  </Link>
                  <Link to="/features">
                    <Button variant="outline" size="lg" className="text-lg">
                      Discover Features
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="md:w-1/2 flex justify-center">
                <Link to="/signup" className="relative w-full block cursor-pointer group">
                  <div className="absolute -inset-4 bg-gradient-to-r from-primary via-accent to-primary rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition duration-300"></div>
                  <div className="relative modern-card overflow-hidden h-80 md:h-96">
                    <img 
                      src="/lovable-uploads/23436f20-0cfc-4c09-b184-4c138f326b9a.png" 
                      alt="Usikwame Kupata Loan - Stay Updated, Access Your CRB Status Today" 
                      className="rounded-2xl w-full h-full object-contain transform group-hover:scale-105 transition duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent rounded-2xl flex items-end">
                      <div className="p-6 text-white">
                        <p className="text-base font-semibold">Stay Updated, Access Your CRB Status Today</p>
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            </div>
            
            {/* Dynamic Statistics Counter */}
            <div className="mt-8">
              <StatisticsCounter />
              
              {/* Trusted by Text and Bank Logos */}
              <div className="mt-6 text-center">
                <p className="text-gray-700 font-medium mb-4">Trusted by thousands of Kenyans and Lending Institutions.</p>
                
                {/* Bank Logos - Modern grid design */}
                <div className="mt-8 grid grid-cols-4 sm:grid-cols-5 md:grid-cols-7 lg:grid-cols-9 gap-3 justify-items-center items-center px-4 md:px-16">
                  {[
                    { src: "/lovable-uploads/37b470e8-6d26-45e0-b4e4-f47182da492e.png", alt: "KCB Bank" },
                    { src: "/lovable-uploads/af2cef6c-e2e5-492c-9d7e-e36af4bf497c.png", alt: "Equity Bank" },
                    { src: "/lovable-uploads/24c39360-de7d-41c8-976d-1363e06fb2eb.png", alt: "Family Bank" },
                    { src: "/lovable-uploads/860fad48-4a51-4bd3-bd39-85539f5d7590.png", alt: "Co-op Bank" },
                    { src: "/lovable-uploads/3cde1503-3b65-466c-8143-02e062131360.png", alt: "Standard Chartered" },
                    { src: "/lovable-uploads/875eabb2-f70b-4ed1-82b6-7c406f781bef.png", alt: "Stanbic Bank" },
                    { src: "/lovable-uploads/d469c5fd-6da8-47d3-be69-f31016c78203.png", alt: "Absa Bank" },
                    { src: "/lovable-uploads/589d22a7-6206-488f-8f0d-efbf225c3dde.png", alt: "I&M Bank" },
                    { src: "/lovable-uploads/d5c29351-b296-4045-8604-43490ee4b8cb.png", alt: "Ecobank" },
                    { src: "/lovable-uploads/843caf60-c8fe-4e9a-b9ae-f1a8cfb87906.png", alt: "National Bank" },
                    { src: "/lovable-uploads/9f7d5aa8-bc1f-4e34-b17a-fba0901abd7c.png", alt: "NCBA" },
                    { src: "/lovable-uploads/97253618-b2c6-4a64-8190-96da655ab711.png", alt: "M-PESA Fuliza" },
                    { src: "/lovable-uploads/ef26fda9-7bfa-48de-a425-54afee39eb6d.png", alt: "Bank of Africa" }
                  ].map((bank, index) => (
                    <div key={index} className="glass-card p-3 hover:scale-105 transition-all duration-300 w-18 h-14 flex items-center justify-center group">
                      <img 
                        src={bank.src} 
                        alt={bank.alt}
                        className="max-h-full max-w-full object-contain opacity-80 group-hover:opacity-100 transition-opacity" 
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Features Section */}
        <section className="py-24 relative">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-semibold mb-4">
                ✨ Why Choose Us
              </div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 font-display">Comprehensive Credit Solutions</h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Transform your financial journey with our cutting-edge platform designed to unlock your borrowing potential.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Link to="/signup" className="block group">
                <div className="modern-card group-hover:scale-[1.02] flex flex-col h-full relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-accent"></div>
                  <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl mb-6">
                    <Shield className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 font-display">Instant CRB Verification</h3>
                  <p className="text-muted-foreground flex-grow leading-relaxed text-lg">
                    Get your CRB status verification instantly without the hassle of physical visits or long waits.
                  </p>
                </div>
              </Link>

              <Link to="/signup" className="block group">
                <div className="modern-card group-hover:scale-[1.02] flex flex-col h-full relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-accent"></div>
                  <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl mb-6">
                    <FileCheck className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 font-display">CRB Blacklist Clearance</h3>
                  <p className="text-muted-foreground flex-grow leading-relaxed text-lg">
                    Get expert assistance to help you remove and clear your name from CRB blacklists through our specialized dispute resolution service.
                  </p>
                </div>
              </Link>

              <Link to="/signup" className="block group">
                <div className="modern-card group-hover:scale-[1.02] flex flex-col h-full relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-accent"></div>
                  <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl mb-6">
                    <CreditCard className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 font-display">Express Loan Connections</h3>
                  <p className="text-muted-foreground flex-grow leading-relaxed text-lg">
                    Connect directly with our partnered lending platforms that can issue loans to you immediately based on your improved credit status.
                  </p>
                </div>
              </Link>
            </div>
          </div>
        </section>
        
        {/* How It Works */}
        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-semibold mb-4">
                📋 Simple Process
              </div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 font-display">How It Works</h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Four simple steps to transform your financial future and unlock borrowing opportunities.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {[
                {
                  step: "1",
                  title: "Create Account",
                  description: "Sign up in minutes with your basic information and ID details."
                },
                {
                  step: "2",
                  title: "Choose Plan",
                  description: "Select the subscription plan that best fits your needs."
                },
                {
                  step: "3",
                  title: "Verify Identity",
                  description: "Complete the secure KYC process for account verification."
                },
                {
                  step: "4",
                  title: "Get Results",
                  description: "Instantly access your CRB status and credit insights."
                }
              ].map((item, index) => (
                <div key={item.step} className="text-center group">
                  <div className="relative mb-8">
                    <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-primary to-accent text-white text-2xl font-bold flex items-center justify-center mx-auto group-hover:scale-110 transition-transform duration-300">
                      {item.step}
                    </div>
                    {index < 3 && (
                      <div className="hidden md:block absolute top-10 left-full w-full h-0.5 bg-gradient-to-r from-primary/30 to-accent/30 -translate-x-1/2"></div>
                    )}
                  </div>
                  <h3 className="text-2xl font-bold mb-4 font-display">{item.title}</h3>
                  <p className="text-muted-foreground text-lg leading-relaxed">{item.description}</p>
                </div>
              ))}
            </div>
            
            <div className="mt-16 text-center">
              <Link to="/signup">
                <Button size="lg" className="text-lg">
                  Start Your Journey
                  <ArrowRight className="ml-2 h-6 w-6" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
        
        {/* Testimonials */}
        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-semibold mb-4">
                💬 Success Stories
              </div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 font-display">What Our Customers Say</h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Join thousands of satisfied customers who've transformed their financial futures with our platform.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-primary/10">
                  {/* Star Rating */}
                  <div className="flex mb-6">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  
                  {/* Testimonial Text */}
                  <div className="mb-6">
                    <p className="text-gray-700 italic leading-relaxed">"{testimonial.testimonial}"</p>
                  </div>
                  
                  {/* User Info */}
                  <div className="flex items-center pt-4 border-t border-gray-100">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary/80 to-accent/80 rounded-full flex items-center justify-center text-white font-bold">
                      {testimonial.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="ml-3">
                      <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
                      <p className="text-sm text-primary">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-24 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary via-accent to-primary"></div>
          <div className="absolute inset-0 opacity-20"></div>
          <div className="container mx-auto px-4 text-center relative z-10">
            <h2 className="text-4xl md:text-6xl font-bold mb-8 text-white font-display">Ready to Transform Your Financial Future?</h2>
            <p className="text-2xl mb-12 max-w-4xl mx-auto text-white/90 leading-relaxed">
              Join thousands of Kenyans who are improving their credit scores and unlocking financial opportunities.
            </p>
            <Link to="/signup">
              <Button size="lg" variant="outline" className="bg-white text-primary hover:bg-white/90 border-white text-xl px-12 py-6">
                Start Your Journey Today
                <ArrowRight className="ml-2 h-6 w-6" />
              </Button>
            </Link>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
