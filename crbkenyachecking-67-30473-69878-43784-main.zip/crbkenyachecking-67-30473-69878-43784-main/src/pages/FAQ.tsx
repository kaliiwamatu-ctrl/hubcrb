
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowRight, HelpCircle } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Separator } from "@/components/ui/separator";
import { Card } from "@/components/ui/card";

const FAQ = () => {
  // FAQ data
  const faqs = [
    {
      id: "faq-1",
      question: "How often is my credit score updated?",
      answer: "Your credit score is updated monthly, with real-time alerts for any significant changes."
    },
    {
      id: "faq-2",
      question: "Is my information secure?",
      answer: "Yes, we use bank-level encryption and security measures to protect your personal information."
    },
    {
      id: "faq-3",
      question: "Can I cancel my subscription anytime?",
      answer: "Yes, you can cancel your subscription at any time with no questions asked."
    },
    {
      id: "faq-4",
      question: "How accurate is the credit score provided?",
      answer: "We provide scores directly from major credit bureaus, ensuring accuracy and reliability."
    },
    {
      id: "faq-5",
      question: "What do I need to check my CRB status?",
      answer: "You'll need your National ID number, a valid phone number, and your full name as it appears on your ID to check your CRB status."
    },
    {
      id: "faq-6",
      question: "How long does it take to get my credit report?",
      answer: "Your credit report is generated instantly after payment verification, and you can access it immediately from your dashboard."
    },
    {
      id: "faq-7",
      question: "What should I do if I find errors in my credit report?",
      answer: "If you find any errors in your report, you can file a dispute directly through our platform. We'll investigate and correct any inaccuracies within 14 business days."
    },
    {
      id: "faq-8",
      question: "How can I improve my credit score?",
      answer: "Our platform provides personalized recommendations to improve your score. Generally, making timely payments, reducing debt, and keeping credit utilization low will help improve your score over time."
    },
    {
      id: "faq-9",
      question: "Do you offer credit repair services?",
      answer: "Yes, we offer credit repair services to help you clear negative listings. Our team of experts will guide you through the process of improving your credit profile."
    },
    {
      id: "faq-10",
      question: "How long does negative information stay on my credit report?",
      answer: "In Kenya, negative information generally stays on your credit report for 5 years from the date of listing. However, this can vary based on the type of negative mark and your actions to resolve it."
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-primary/5 py-12 md:py-20">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h1>
              <p className="text-lg text-gray-600 mb-8">
                Find answers to common questions about our service
              </p>
            </div>
          </div>
        </section>
        
        {/* FAQ Accordion Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 max-w-4xl">
            <Accordion type="single" collapsible className="w-full space-y-6">
              {faqs.map((faq) => (
                <Card key={faq.id} className="overflow-hidden">
                  <AccordionItem value={faq.id} className="border-none">
                    <AccordionTrigger className="px-6 py-4 text-left hover:no-underline bg-card">
                      <span className="font-medium text-base md:text-lg">{faq.question}</span>
                    </AccordionTrigger>
                    <AccordionContent className="px-6 pt-0 pb-4 text-gray-600">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                </Card>
              ))}
            </Accordion>
          </div>
        </section>
        
        {/* Additional Questions Section */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-6">Still have questions?</h2>
            <p className="text-lg mb-8 max-w-2xl mx-auto">
              Contact our support team for more information or to get help with any specific concerns.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/contact">
                <Button size="lg" className="w-full sm:w-auto">
                  Contact Support
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default FAQ;
