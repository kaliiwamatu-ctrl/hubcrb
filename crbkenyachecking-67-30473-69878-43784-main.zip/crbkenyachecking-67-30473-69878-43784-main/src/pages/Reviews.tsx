import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ArrowRight, Star, MessageSquare, Users } from "lucide-react";

const Reviews = () => {
  // Reviews data
  const testimonials = [
    {
      id: 1,
      name: "John Kamau",
      role: "Business Owner",
      rating: 5,
      testimonial: "CRB Checker helped me understand my credit status and improve my score, which allowed me to secure a business loan for my retail shop. Their customer service was exceptional, and they guided me through every step.",
      date: "March 15, 2023"
    },
    {
      id: 2,
      name: "Faith Wangari",
      role: "Teacher",
      rating: 5,
      testimonial: "I was able to clear my CRB listing using the guidance provided by CRB Checker. Now I can access financial services again. The personalized action plan they created for me made all the difference in improving my score.",
      date: "February 8, 2023"
    },
    {
      id: 3,
      name: "David Omondi",
      role: "Software Developer",
      rating: 4,
      testimonial: "The credit score monitoring has been invaluable. I get alerts whenever there's a change, helping me maintain a good score. Their mobile app is also very intuitive and provides real-time updates.",
      date: "April 22, 2023"
    },
    {
      id: 4,
      name: "Sarah Njeri",
      role: "Healthcare Professional",
      rating: 5,
      testimonial: "After years of struggling with loans, CRB Checker gave me the tools to understand and improve my financial standing. Their comprehensive reports are easy to understand, even for someone with no financial background.",
      date: "January 12, 2023"
    },
    {
      id: 5,
      name: "Peter Maina",
      role: "Entrepreneur",
      rating: 5,
      testimonial: "Thanks to CRB Checker, I was able to negotiate better loan terms with my bank. The detailed credit analysis they provided gave me leverage during discussions with financial institutions.",
      date: "May 5, 2023"
    },
    {
      id: 6,
      name: "Lucy Akinyi",
      role: "Marketing Manager",
      rating: 4,
      testimonial: "The credit improvement plan from CRB Checker was tailored specifically to my situation. Within 6 months, my score improved significantly, and I qualified for a mortgage.",
      date: "June 18, 2023"
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-primary/5 py-12 md:py-20">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Customer Reviews & Testimonials</h1>
              <p className="text-lg text-gray-600 mb-8">
                Don't just take our word for it. Here's what our satisfied customers have to say about CRB Checker's services.
              </p>
              <div className="flex justify-center items-center space-x-8 mb-8">
                <div className="flex flex-col items-center">
                  <Users className="h-10 w-10 text-primary mb-2" />
                  <span className="text-2xl font-bold">2,000,000+</span>
                  <span className="text-gray-600">Happy Clients</span>
                </div>
                <div className="flex flex-col items-center">
                  <Star className="h-10 w-10 text-primary mb-2" />
                  <span className="text-2xl font-bold">4.9/5</span>
                  <span className="text-gray-600">Average Rating</span>
                </div>
                <div className="flex flex-col items-center">
                  <MessageSquare className="h-10 w-10 text-primary mb-2" />
                  <span className="text-2xl font-bold">6,000+</span>
                  <span className="text-gray-600">Reviews</span>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Testimonials Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-200">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center text-primary font-bold text-lg mr-4">
                        {testimonial.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <h4 className="font-semibold">{testimonial.name}</h4>
                        <p className="text-sm text-gray-500">{testimonial.role}</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-400">{testimonial.date}</span>
                  </div>
                  <div className="flex mb-3">
                    {Array(5).fill(0).map((_, index) => (
                      <Star 
                        key={index} 
                        className={`h-4 w-4 ${index < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`} 
                      />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4">"{testimonial.testimonial}"</p>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-6">Ready to Join Our Satisfied Customers?</h2>
            <p className="text-lg mb-8 max-w-2xl mx-auto">
              Start your journey to better financial health today and become one of our success stories.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/signup">
                <Button size="lg" className="w-full sm:w-auto">
                  Check Your CRB Status Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/contact">
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Reviews;
