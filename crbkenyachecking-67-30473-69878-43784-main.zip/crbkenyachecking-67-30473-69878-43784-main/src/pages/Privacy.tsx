
import React from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const Privacy = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-12 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="mb-6">
            <Link to="/">
              <Button variant="ghost" size="sm" className="mb-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Privacy Policy</h1>
            <p className="text-gray-500">Last updated: May 11, 2025</p>
          </div>
          
          <div className="bg-white p-6 md:p-8 rounded-xl shadow-sm">
            <div className="prose prose-slate max-w-none">
              <p>At Metropol CRB Checker, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our service.</p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">1. Information We Collect</h2>
              <p>We collect several types of information for various purposes to provide and improve our service to you:</p>
              
              <h3 className="text-lg font-medium mt-5 mb-2">1.1 Personal Information</h3>
              <p>When you register or use our services, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. This may include:</p>
              <ul className="list-disc pl-6 my-3">
                <li>Full name</li>
                <li>National ID or passport number</li>
                <li>Contact information (email address, phone number)</li>
                <li>Date of birth</li>
                <li>Financial information necessary for CRB checks</li>
                <li>Payment information (for subscription services)</li>
              </ul>
              
              <h3 className="text-lg font-medium mt-5 mb-2">1.2 Usage Data</h3>
              <p>We may also collect information on how you access and use our service (Usage Data). This may include:</p>
              <ul className="list-disc pl-6 my-3">
                <li>IP address</li>
                <li>Browser type and version</li>
                <li>Pages visited and time spent</li>
                <li>Device information</li>
                <li>Date and time of your visit</li>
                <li>Other diagnostic data</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">2. How We Use Your Information</h2>
              <p>We use the collected information for various purposes, including to:</p>
              <ul className="list-disc pl-6 my-3">
                <li>Provide and maintain our service</li>
                <li>Process your CRB status checks</li>
                <li>Notify you about changes to our service</li>
                <li>Allow you to participate in interactive features</li>
                <li>Provide customer support</li>
                <li>Monitor the usage of our service</li>
                <li>Detect, prevent, and address technical issues</li>
                <li>Improve our service</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">3. Data Security</h2>
              <p>The security of your data is important to us, but remember that no method of transmission over the Internet or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your personal information, we cannot guarantee its absolute security.</p>
              <p>We implement a variety of security measures to maintain the safety of your personal information, including:</p>
              <ul className="list-disc pl-6 my-3">
                <li>Encryption of sensitive data</li>
                <li>Regular security assessments</li>
                <li>Secure authentication methods</li>
                <li>Limited employee access to personal information</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">4. Third-Party Service Providers</h2>
              <p>We may employ third-party companies and individuals to facilitate our service ("Service Providers"), provide the service on our behalf, perform service-related services, or assist us in analyzing how our service is used.</p>
              <p>These third parties have access to your personal information only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose. They include:</p>
              <ul className="list-disc pl-6 my-3">
                <li>Credit Reference Bureaus for credit information</li>
                <li>Payment processors for handling subscription payments</li>
                <li>Analytics providers to help us understand usage</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">5. Data Retention</h2>
              <p>We will retain your personal information only for as long as is necessary for the purposes set out in this Privacy Policy. We will retain and use your information to the extent necessary to comply with our legal obligations, resolve disputes, and enforce our policies.</p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">6. Your Data Protection Rights</h2>
              <p>Under data protection laws, you have rights including:</p>
              <ul className="list-disc pl-6 my-3">
                <li>The right to access your personal data</li>
                <li>The right to correction of inaccurate data</li>
                <li>The right to erasure (the "right to be forgotten")</li>
                <li>The right to restrict processing</li>
                <li>The right to object to processing</li>
                <li>The right to data portability</li>
              </ul>
              <p>To exercise any of these rights, please contact us using the information provided in the "Contact Us" section.</p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">7. Contact Us</h2>
              <p>If you have any questions about this Privacy Policy, please contact us:</p>
              <ul className="list-disc pl-6 my-3">
                <li>By email: privacy@instantcrbchecker.co.ke</li>
                <li>By visiting our contact page: <Link to="/contact" className="text-primary hover:underline">Contact Page</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Privacy;

