
import React from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { 
  Shield, 
  RefreshCcw, 
  BookOpen, 
  Clock, 
  AlertTriangle, 
  ArrowRight, 
  BarChart, 
  Lock, 
  FileText,
  CheckCircle2,
  TrendingUp,
  BanknoteIcon,
  ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Features = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-primary/10 to-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Unique Features</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Discover the innovative tools and services that make KenyaCRB the leading credit reference platform in Kenya.
            </p>
          </div>
        </section>
        
        {/* Core Features */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Core Features</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all p-8 border border-gray-100">
                <div className="h-14 w-14 bg-primary/10 rounded-lg flex items-center justify-center mb-5">
                  <Shield className="h-7 w-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Instant CRB Status Verification</h3>
                <p className="text-gray-600 mb-4">
                  Get your credit status verified within minutes, not days. Our real-time verification system connects directly with all major credit bureaus in Kenya.
                </p>
                <ul className="space-y-2 mb-5">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Real-time credit bureau connections</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Verification certificates</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Digital delivery to your email</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all p-8 border border-gray-100">
                <div className="h-14 w-14 bg-primary/10 rounded-lg flex items-center justify-center mb-5">
                  <BanknoteIcon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Express Loan Connections</h3>
                <p className="text-gray-600 mb-4">
                  Connect directly with our partnered lending platforms that can issue loans to you immediately based on your improved credit status.
                </p>
                <ul className="space-y-2 mb-5">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Fast loan approvals</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Trusted lending partners</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Competitive interest rates</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all p-8 border border-gray-100">
                <div className="h-14 w-14 bg-primary/10 rounded-lg flex items-center justify-center mb-5">
                  <ShieldCheck className="h-7 w-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">CRB Blacklist Clearance</h3>
                <p className="text-gray-600 mb-4">
                  Get expert assistance to help you remove and clear your name from CRB blacklists through our specialized dispute resolution service.
                </p>
                <ul className="space-y-2 mb-5">
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Expert dispute resolution</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Removal of incorrect listings</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Documentation assistance</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
        
        {/* Why Choose Us */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-4">Why Choose KenyaCRB</h2>
            <p className="text-center text-gray-600 max-w-3xl mx-auto mb-12">
              We stand out from other credit reference services with our unique approach to financial empowerment.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex items-start space-x-4 p-6 bg-white rounded-lg shadow-sm">
                <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Clock className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">24/7 Access</h3>
                  <p className="text-gray-600">
                    Unlike traditional CRB services that operate during business hours, our platform is available 24/7. Check your credit status anytime, anywhere.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4 p-6 bg-white rounded-lg shadow-sm">
                <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Lock className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Bank-Level Security</h3>
                  <p className="text-gray-600">
                    Your financial data is protected with enterprise-grade encryption and security protocols that meet international standards.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4 p-6 bg-white rounded-lg shadow-sm">
                <div className="h-12 w-12 bg-yellow-100 rounded-full flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-yellow-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Fraud Detection</h3>
                  <p className="text-gray-600">
                    Our advanced algorithms detect suspicious activities on your credit profile, alerting you to potential identity theft or fraud.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4 p-6 bg-white rounded-lg shadow-sm">
                <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <BookOpen className="h-6 w-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Financial Education</h3>
                  <p className="text-gray-600">
                    Access our extensive library of financial education resources designed specifically for the Kenyan market and regulatory environment.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4 p-6 bg-white rounded-lg shadow-sm">
                <div className="h-12 w-12 bg-red-100 rounded-full flex items-center justify-center">
                  <FileText className="h-6 w-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Comprehensive Reports</h3>
                  <p className="text-gray-600">
                    Our reports include data from all major credit bureaus in Kenya, giving you the most complete picture of your credit health.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4 p-6 bg-white rounded-lg shadow-sm">
                <div className="h-12 w-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <Shield className="h-6 w-6 text-orange-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Government Approved</h3>
                  <p className="text-gray-600">
                    We are fully compliant with Kenyan financial regulations and approved by the Central Bank of Kenya for credit reference services.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Premium Features */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="bg-secondary/10 rounded-2xl p-8 md:p-12">
              <div className="text-center mb-10">
                <h2 className="text-3xl font-bold mb-4">Premium Features</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Unlock additional powerful features with our premium plans to get even more control over your financial future.
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-lg p-6 shadow-sm">
                  <h3 className="font-semibold text-lg mb-3">Loan Eligibility Predictor</h3>
                  <p className="text-gray-600">
                    Our AI-powered tool analyzes your credit profile to predict your likelihood of approval for various loan products.
                  </p>
                </div>
                
                <div className="bg-white rounded-lg p-6 shadow-sm">
                  <h3 className="font-semibold text-lg mb-3">Credit Score Simulator</h3>
                  <p className="text-gray-600">
                    See how different financial decisions could impact your credit score before you make them.
                  </p>
                </div>
                
                <div className="bg-white rounded-lg p-6 shadow-sm">
                  <h3 className="font-semibold text-lg mb-3">Tips to Raise Your Credit Score Instantly</h3>
                  <p className="text-gray-600">
                    Access personalized, actionable recommendations to improve your credit score quickly and effectively.
                  </p>
                </div>
                
                <div className="bg-white rounded-lg p-6 shadow-sm">
                  <div className="flex items-start gap-2 mb-3">
                    <ShieldCheck className="h-5 w-5 text-primary mt-0.5" />
                    <h3 className="font-semibold text-lg">CRB Blacklist Clearance</h3>
                  </div>
                  <p className="text-gray-600">
                    Get expert assistance to help you remove and clear your name from CRB blacklists through our specialized dispute resolution service.
                  </p>
                </div>
                
                <div className="bg-white rounded-lg p-6 shadow-sm">
                  <div className="flex items-start gap-2 mb-3">
                    <BanknoteIcon className="h-5 w-5 text-primary mt-0.5" />
                    <h3 className="font-semibold text-lg">Express Loan Connections</h3>
                  </div>
                  <p className="text-gray-600">
                    Connect directly with our partnered lending platforms that can issue loans to you immediately based on your improved credit status.
                  </p>
                </div>
                
                <div className="bg-white rounded-lg p-6 shadow-sm">
                  <h3 className="font-semibold text-lg mb-3">Personal Finance Manager</h3>
                  <p className="text-gray-600">
                    Track your spending, set budgets, and receive personalized recommendations to improve your financial health.
                  </p>
                </div>
              </div>
              
              <div className="mt-10 text-center">
                <Link to="/signup">
                  <Button className="cta-button text-base">
                    Get Started Today
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Features;
