
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "@/components/ui/use-toast";
import { 
  CreditCard, 
  Briefcase, 
  Home, 
  Building2, 
  BarChart3, 
  Scale 
} from "lucide-react";
import ReportProgress from "@/components/ReportProgress";
import CustomSubscriptionModal from "@/components/CustomSubscriptionModal";
import { ensureUserData } from "@/utils/userStorage";

const ReportPurpose = () => {
  const navigate = useNavigate();
  const [selectedPurpose, setSelectedPurpose] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showSubscription, setShowSubscription] = useState(false);

  useEffect(() => {
    // Ensure user data exists in localStorage
    ensureUserData();
  }, []);

  const reportOptions = [
    { id: "loan", name: "Loan Application", icon: <CreditCard className="h-6 w-6 text-primary" /> },
    { id: "employment", name: "Employment", icon: <Briefcase className="h-6 w-6 text-primary" /> },
    { id: "housing", name: "Housing/Rental", icon: <Home className="h-6 w-6 text-primary" /> },
    { id: "business", name: "Business", icon: <Building2 className="h-6 w-6 text-primary" /> },
    { id: "personal", name: "Personal Review", icon: <BarChart3 className="h-6 w-6 text-primary" /> },
    { id: "legal", name: "Legal Matters", icon: <Scale className="h-6 w-6 text-primary" /> },
  ];

  const handleOptionSelect = (id: string) => {
    setSelectedPurpose(id);
  };

  const handleGenerateReport = () => {
    if (!selectedPurpose) {
      toast({
        title: "Please select a purpose",
        description: "You must select a report purpose to continue",
        variant: "destructive",
      });
      return;
    }

    // Store the selected purpose in local storage
    localStorage.setItem("reportPurpose", selectedPurpose);
    
    // Show the loading progress
    setIsLoading(true);
    
    // The ReportProgress component will call onComplete when it reaches 100%
  };

  const handleProgressComplete = () => {
    setIsLoading(false);
    setShowSubscription(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-[#f7f9fe] to-[#eef1f9]">
      <Navbar />
      
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold text-center mb-3 gradient-text">Select Report Purpose</h1>
            <p className="text-center text-gray-600 mb-8">Choose the main reason why you need your CRB report</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {reportOptions.map((option) => (
                <Card 
                  key={option.id}
                  className={`morphic-card hover:scale-[1.02] transition-all cursor-pointer ${
                    selectedPurpose === option.id ? "border-primary shadow-[8px_8px_16px_0px_rgba(123,82,171,0.2),_-8px_-8px_16px_0px_rgba(255,255,255,0.9)]" : ""
                  }`}
                  onClick={() => handleOptionSelect(option.id)}
                >
                  <CardContent className="p-6 flex items-center space-x-4">
                    <div className="shrink-0 bg-gradient-to-br from-primary/10 to-primary/5 p-3 rounded-xl">
                      {option.icon}
                    </div>
                    <div className="text-lg font-medium text-gray-800">{option.name}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <Button 
              onClick={handleGenerateReport}
              className="w-full py-6 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl"
              size="lg"
            >
              Generate My CRB Report
            </Button>
          </div>
        </div>
      </main>
      
      <Footer />

      {/* Loading Progress Dialog */}
      <ReportProgress 
        open={isLoading} 
        onComplete={handleProgressComplete} 
      />

      {/* Custom Subscription Modal */}
      <CustomSubscriptionModal 
        open={showSubscription} 
        onOpenChange={setShowSubscription} 
      />
    </div>
  );
};

export default ReportPurpose;
