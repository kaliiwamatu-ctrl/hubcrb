
import React from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const Terms = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-12 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="mb-6">
            <Link to="/">
              <Button variant="ghost" size="sm" className="mb-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Terms and Conditions</h1>
            <p className="text-gray-500">Last updated: May 11, 2025</p>
          </div>
          
          <div className="bg-white p-6 md:p-8 rounded-xl shadow-sm">
            <div className="prose prose-slate max-w-none">
              <p>Welcome to Metropol CRB Checker. Please read these Terms and Conditions carefully before using our services.</p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">1. Acceptance of Terms</h2>
              <p>By accessing or using Metropol CRB Checker services, you agree to be bound by these Terms and Conditions. If you disagree with any part of the terms, you may not access the service.</p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">2. Service Description</h2>
              <p>Metropol CRB Checker provides credit reference bureau (CRB) verification services, credit score access, blacklist clearance assistance, and loan connection services. We help users understand their credit status and improve their financial standing.</p>
...
              <h2 className="text-xl font-semibold mt-6 mb-3">5. Privacy Policy</h2>
              <p>Your use of Metropol CRB Checker is also governed by our Privacy Policy, which outlines how we collect, use, and protect your personal information.</p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">6. User Conduct</h2>
              <p>You agree not to:</p>
              <ul className="list-disc pl-6 my-3">
                <li>Use the service for any illegal purpose or in violation of any laws</li>
                <li>Impersonate any person or entity or falsely state your affiliation</li>
                <li>Interfere with or disrupt the service or servers connected to the service</li>
                <li>Attempt to gain unauthorized access to any part of the service</li>
                <li>Submit false or misleading information</li>
              </ul>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">7. Data Accuracy</h2>
              <p>While we strive to provide accurate information, we cannot guarantee the absolute accuracy of credit reports or scores provided. The information is sourced from third-party credit bureaus, and we do not independently verify the data.</p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">8. Changes to Terms</h2>
              <p>We reserve the right to modify or replace these Terms at any time. Your continued use of the service after any such changes constitutes acceptance of the new Terms.</p>
              
              <h2 className="text-xl font-semibold mt-6 mb-3">9. Contact Information</h2>
              <p>If you have any questions about these Terms, please contact us at support@metropolcrbchecker.co.ke.</p>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Terms;
