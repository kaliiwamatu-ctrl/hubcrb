import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const callbackData = await req.json();
    console.log('PayHero callback received:', JSON.stringify(callbackData, null, 2));

    // Create Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Extract payment details from callback - PayHero sends nested response object
    const response = callbackData.response || callbackData;
    const externalReference = response.ExternalReference || callbackData.external_reference;
    const status = response.Status || callbackData.status;
    const paymentId = callbackData.id || callbackData.payment_id;

    console.log('Processing payment:', { paymentId, status, externalReference, fullResponse: response });

    // Find the transaction by external reference first, then payment ID
    let transactionsQuery = supabase
      .from('payment_transactions')
      .select('*');
    
    if (externalReference) {
      transactionsQuery = transactionsQuery.or(`transaction_reference.eq.${externalReference}${paymentId ? `,transaction_reference.eq.${paymentId}` : ''}`);
    } else if (paymentId) {
      transactionsQuery = transactionsQuery.eq('transaction_reference', paymentId.toString());
    } else {
      console.error('No reference found in callback data');
      throw new Error('No payment reference found');
    }

    const { data: transactions, error: fetchError } = await transactionsQuery;

    if (fetchError) {
      console.error('Error fetching transaction:', fetchError);
      throw fetchError;
    }

    if (!transactions || transactions.length === 0) {
      console.error('Transaction not found for reference:', externalReference || paymentId);
      return new Response(
        JSON.stringify({ error: 'Transaction not found' }),
        {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const transaction = transactions[0];
    console.log('Found transaction:', transaction.id);

    // Determine transaction status based on PayHero status
    let transactionStatus = 'pending';
    const statusUpper = (status || '').toString().toUpperCase();
    
    // Check ResultCode if available (0 = success, others = failure)
    const resultCode = response.ResultCode;
    if (resultCode === 0 || statusUpper === 'COMPLETE' || statusUpper === 'COMPLETED' || statusUpper === 'SUCCESS') {
      transactionStatus = 'approved';
    } else if (resultCode !== undefined && resultCode !== 0) {
      transactionStatus = 'failed';
    } else if (statusUpper === 'FAILED' || statusUpper === 'REJECTED') {
      transactionStatus = 'failed';
    }

    // Update transaction status
    const { error: updateError } = await supabase
      .from('payment_transactions')
      .update({
        status: transactionStatus,
        updated_at: new Date().toISOString(),
      })
      .eq('id', transaction.id);

    if (updateError) {
      console.error('Error updating transaction:', updateError);
      throw updateError;
    }

    console.log(`Transaction ${transaction.id} updated to ${transactionStatus}`);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Callback processed successfully',
        transactionId: transaction.id,
        status: transactionStatus,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error: any) {
    console.error('Error in payhero-callback:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Internal server error',
        details: error.toString(),
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
