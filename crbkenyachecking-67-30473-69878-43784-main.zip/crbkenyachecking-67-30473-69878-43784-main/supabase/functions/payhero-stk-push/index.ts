import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface PaymentRequest {
  amount: number;
  phoneNumber: string;
  userId?: string;
  packageType: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { amount, phoneNumber, userId, packageType }: PaymentRequest = await req.json();

    console.log('Processing PayHero STK Push:', { amount, phoneNumber, packageType });

    // Get PayHero credentials from environment secrets
    const apiUsername = Deno.env.get('PAYHERO_API_USERNAME');
    const apiPassword = Deno.env.get('PAYHERO_API_PASSWORD');
    const channelId = Deno.env.get('PAYHERO_CHANNEL_ID');

    // Validate credentials exist
    if (!apiUsername || !apiPassword || !channelId) {
      throw new Error('PayHero credentials not configured');
    }

    // Format phone number for Kenya (254XXXXXXXXX)
    let formattedPhone = phoneNumber;
    if (phoneNumber.startsWith('0')) {
      formattedPhone = '254' + phoneNumber.substring(1);
    } else if (phoneNumber.startsWith('7') || phoneNumber.startsWith('1')) {
      formattedPhone = '254' + phoneNumber;
    } else if (!phoneNumber.startsWith('254')) {
      formattedPhone = '254' + phoneNumber;
    }

    console.log('Formatted phone number:', formattedPhone);

    // Create Basic Auth token
    const basicAuth = btoa(`${apiUsername}:${apiPassword}`);

    // Create Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Create payment transaction record
    const externalReference = `PKG-${Date.now()}`;
    
    // Validate userId is a UUID if provided
    let validUserId = null;
    if (userId) {
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      if (uuidRegex.test(userId)) {
        validUserId = userId;
      } else {
        console.log('Invalid UUID format for userId, setting to null:', userId);
      }
    }
    
    const { data: transaction, error: dbError } = await supabase
      .from('payment_transactions')
      .insert({
        user_id: validUserId,
        amount: amount,
        description: `${packageType} package payment`,
        status: 'pending',
        payment_method: 'mpesa',
        transaction_reference: externalReference,
      })
      .select()
      .single();

    if (dbError) {
      console.error('Database error:', dbError);
      throw dbError;
    }

    console.log('Created transaction:', transaction.id);

    // PayHero STK Push request payload
    const payHeroPayload = {
      amount: amount,
      phone_number: formattedPhone,
      channel_id: parseInt(channelId),
      provider: "m-pesa",
      external_reference: externalReference,
      callback_url: `${supabaseUrl}/functions/v1/payhero-callback`,
    };

    console.log('Sending request to PayHero API...');

    // Make request to PayHero API
    const payHeroResponse = await fetch(
      'https://backend.payhero.co.ke/api/v2/payments',
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${basicAuth}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payHeroPayload),
      }
    );

    const payHeroData = await payHeroResponse.json();
    console.log('PayHero response:', payHeroData);

    if (!payHeroResponse.ok) {
      console.error('PayHero API error:', payHeroData);
      
      // Update transaction status to failed
      await supabase
        .from('payment_transactions')
        .update({ status: 'failed' })
        .eq('id', transaction.id);

      return new Response(
        JSON.stringify({
          error: 'Payment initiation failed',
          details: payHeroData,
        }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Update transaction with PayHero payment ID
    if (payHeroData.id) {
      await supabase
        .from('payment_transactions')
        .update({ 
          transaction_reference: payHeroData.id.toString(),
        })
        .eq('id', transaction.id);
    }

    return new Response(
      JSON.stringify({
        success: true,
        transactionId: transaction.id,
        payHeroResponse: payHeroData,
        message: 'STK push sent successfully. Please check your phone.',
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error: any) {
    console.error('Error in payhero-stk-push:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Internal server error',
        details: error.toString(),
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
